# Changelog

## v0.5.0
- Added runtime integration guide and acceptance test plan
- Added kernel Dockerfile and integration compose template
- Added Dify HTTP Request + Code node example pack
- Added LiteLLM proxy config and custom callback handler example
- Added LangGraph interrupt-based agent governance example
- Added Open WebUI Pipe and Filter examples
- Added runtime smoke fixtures and script
- Added auth-aware HTTP client and one extra test
