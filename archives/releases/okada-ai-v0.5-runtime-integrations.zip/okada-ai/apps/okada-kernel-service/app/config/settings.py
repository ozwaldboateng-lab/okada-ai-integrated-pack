from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    audit_dir: Path
    default_policy: str
    service_port: int
    service_name: str
    shared_token: str | None
    require_auth: bool

    @classmethod
    def from_env(cls) -> "Settings":
        audit_dir = Path(os.getenv("OKADA_AUDIT_DIR", "./data/audit"))
        default_policy = os.getenv("OKADA_DEFAULT_POLICY", "default")
        service_port = int(os.getenv("OKADA_SERVICE_PORT", "8080"))
        service_name = os.getenv("OKADA_SERVICE_NAME", "okada-kernel")
        shared_token = os.getenv("OKADA_SHARED_TOKEN")
        require_auth = os.getenv("OKADA_REQUIRE_AUTH", "false").lower() in {"1", "true", "yes"}
        return cls(
            audit_dir=audit_dir,
            default_policy=default_policy,
            service_port=service_port,
            service_name=service_name,
            shared_token=shared_token,
            require_auth=require_auth,
        )


settings = Settings.from_env()
settings.audit_dir.mkdir(parents=True, exist_ok=True)
