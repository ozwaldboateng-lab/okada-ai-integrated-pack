from __future__ import annotations

from fastapi import FastAPI

from app.api.routes import router

app = FastAPI(title="Okada Governance Kernel", version="0.5.0")
app.include_router(router)
