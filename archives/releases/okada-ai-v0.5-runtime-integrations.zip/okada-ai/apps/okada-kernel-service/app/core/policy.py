from __future__ import annotations

from app.models.contracts import PolicyProfile


DEFAULT_THRESHOLDS = {
    "T_clean": 0.45,
    "T_contam": 0.95,
    "high_risk_bonus": 0.15,
}

DEFAULT_WEIGHTS = {
    "W_dom": 1.0,
    "W_hist": 1.0,
    "W_comp": 1.0,
}


def resolve_policy(profile: PolicyProfile | None) -> PolicyProfile:
    if profile is None:
        return PolicyProfile(thresholds=DEFAULT_THRESHOLDS.copy(), weights=DEFAULT_WEIGHTS.copy())
    thresholds = DEFAULT_THRESHOLDS.copy()
    thresholds.update(profile.thresholds)
    weights = DEFAULT_WEIGHTS.copy()
    weights.update(profile.weights)
    return PolicyProfile(
        profile_name=profile.profile_name,
        deterministic_mode=profile.deterministic_mode,
        thresholds=thresholds,
        weights=weights,
        preferred_actions=profile.preferred_actions,
    )
