from __future__ import annotations

from app.integrations.http_client import OkadaHttpClient
from app.models.contracts import DiagnoseRequest


def route_for_openwebui(request: DiagnoseRequest, base_url: str | None = None) -> dict:
    client = OkadaHttpClient(base_url=base_url)
    result = client.route(request)
    return {
        "selected_action": result.recommended_action,
        "regime": result.regime,
        "audit_trace_id": result.audit_trace_id,
        "alternatives": result.alternatives,
    }
