# Dify Integration Example

Dify's HTTP Request node can call the Okada kernel with a JSON POST body and variable substitution from previous nodes.
The Code node can then normalize the response and expose branch variables for downstream conditional nodes.

This folder contains:
- `rag_workflow_blueprint.yaml`: human-readable workflow blueprint
- `http_request_payload.json`: example payload for `/okada/diagnose`
- `code_node_transform.py`: code node snippet to reshape the kernel response
- `conditional_branch_matrix.md`: how to map `recommended_action` to Dify branches

Use this as a build guide, not as a guaranteed importable Dify export.
