# Open WebUI Integration Example

Open WebUI can expose custom models via Pipe functions and monitor or transform messages via Filters.

This folder contains:
- `okada_governance_pipe.py`: route-aware custom model pipe
- `okada_audit_filter.py`: inlet/outlet filter for governance metadata and audit
