from __future__ import annotations

import os

import httpx
from pydantic import BaseModel, Field


class Filter:
    class Valves(BaseModel):
        OKADA_BASE_URL: str = Field(default=os.getenv("OKADA_BASE_URL", "http://localhost:8080"))
        OKADA_SHARED_TOKEN: str = Field(default=os.getenv("OKADA_SHARED_TOKEN", ""))
        BLOCK_ON_CONTAMINATED: bool = Field(default=False)

    def __init__(self):
        self.valves = self.Valves()

    def _headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.valves.OKADA_SHARED_TOKEN:
            headers["Authorization"] = f"Bearer {self.valves.OKADA_SHARED_TOKEN}"
        return headers

    async def inlet(self, body: dict, __user__: dict | None = None):
        last_user = ""
        for m in reversed(body.get("messages", [])):
            if m.get("role") == "user":
                last_user = m.get("content", "")
                break

        payload = {
            "spec_id": "OKD-AI-001",
            "adapter_type": "monitoring",
            "observables": {
                "confidence_trend": 0.5,
                "calibration_error_trend": 0.2,
                "fallback_rate": 0.1,
                "override_rate": 0.0,
                "latency_instability": 0.1,
                "output_shift_score": 0.1,
            },
            "context": {
                "last_user_message": last_user,
                "user_id": (__user__ or {}).get("id", ""),
            },
            "history_state": {},
            "resource_state": {},
            "policy_profile": {
                "profile_name": "default",
                "deterministic_mode": True,
            },
        }

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(
                f"{self.valves.OKADA_BASE_URL}/okada/diagnose",
                json=payload,
                headers=self._headers(),
            )
            response.raise_for_status()
            decision = response.json()

        body.setdefault("metadata", {})
        body["metadata"]["okada_regime"] = decision.get("regime")
        body["metadata"]["okada_action"] = decision.get("recommended_action")
        body["metadata"]["okada_audit_trace_id"] = decision.get("audit_trace_id")

        if self.valves.BLOCK_ON_CONTAMINATED and decision.get("regime") == "contaminated":
            raise RuntimeError("Blocked by Okada governance filter")
        return body

    async def outlet(self, body: dict, __user__: dict | None = None):
        return body
