from __future__ import annotations

import os
from typing import Any

import httpx
from pydantic import BaseModel, Field


class Pipe:
    class Valves(BaseModel):
        NAME_PREFIX: str = Field(default="OKADA/")
        CHEAP_MODEL_ID: str = Field(default="gpt-4o-mini")
        STRONG_MODEL_ID: str = Field(default="gpt-4.1")
        OKADA_BASE_URL: str = Field(default=os.getenv("OKADA_BASE_URL", "http://localhost:8080"))
        OKADA_SHARED_TOKEN: str = Field(default=os.getenv("OKADA_SHARED_TOKEN", ""))

    def __init__(self):
        self.valves = self.Valves()

    def pipes(self):
        return [
            {"id": "okada.router", "name": f"{self.valves.NAME_PREFIX}router"},
        ]

    def _headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.valves.OKADA_SHARED_TOKEN:
            headers["Authorization"] = f"Bearer {self.valves.OKADA_SHARED_TOKEN}"
        return headers

    async def pipe(self, body: dict, __user__: dict | None = None) -> Any:
        messages = body.get("messages", [])
        last_user = ""
        for m in reversed(messages):
            if m.get("role") == "user":
                last_user = m.get("content", "")
                break

        payload = {
            "spec_id": "OKD-AI-005",
            "adapter_type": "routing",
            "observables": {
                "complexity_proxy": min(1.0, len(last_user) / 2000.0),
                "historical_route_success": 0.5,
                "risk_class": "standard",
            },
            "context": {
                "messages_count": len(messages),
                "user_id": (__user__ or {}).get("id", ""),
            },
            "history_state": {},
            "resource_state": {
                "budget_remaining": 1.0,
                "latency_load_state": 0.5,
            },
            "policy_profile": {
                "profile_name": "default",
                "deterministic_mode": True,
            },
        }

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(
                f"{self.valves.OKADA_BASE_URL}/okada/route",
                json=payload,
                headers=self._headers(),
            )
            response.raise_for_status()
            decision = response.json()

        selected_model = self.valves.CHEAP_MODEL_ID
        if decision.get("recommended_action") in {"promote_strong_model", "bounded_hybrid"}:
            selected_model = self.valves.STRONG_MODEL_ID

        return {
            "selected_model": selected_model,
            "okada_regime": decision.get("regime"),
            "okada_action": decision.get("recommended_action"),
            "okada_audit_trace_id": decision.get("audit_trace_id"),
        }
