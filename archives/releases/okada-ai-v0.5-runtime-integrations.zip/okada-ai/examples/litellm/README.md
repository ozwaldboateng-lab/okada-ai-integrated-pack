# LiteLLM Integration Example

LiteLLM proxy supports proxy-specific hooks such as `async_pre_call_hook` and `async_post_call_success_hook`.
Use the pre-call hook to ask the Okada kernel which model/route should be used.
Use the post-call hook to emit audit events.

This folder contains:
- `proxy_config.yaml`: example LiteLLM proxy configuration
- `okada_custom_handler.py`: custom callback class
- `request_metadata_mapping.md`: what metadata to attach to requests
