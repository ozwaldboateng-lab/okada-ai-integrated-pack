from __future__ import annotations

import os
from typing import Any, Literal, Optional

import httpx
from litellm.integrations.custom_logger import CustomLogger
from litellm.proxy.proxy_server import DualCache, UserAPIKeyAuth


class OkadaLiteLLMHandler(CustomLogger):
    def __init__(self) -> None:
        super().__init__()
        self.okada_base_url = os.getenv("OKADA_BASE_URL", "http://localhost:8080")
        self.okada_shared_token = os.getenv("OKADA_SHARED_TOKEN")

    def _headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.okada_shared_token:
            headers["Authorization"] = f"Bearer {self.okada_shared_token}"
        return headers

    async def async_pre_call_hook(
        self,
        user_api_key_dict: UserAPIKeyAuth,
        cache: DualCache,
        data: dict,
        call_type: Literal[
            "completion",
            "text_completion",
            "embeddings",
            "image_generation",
            "moderation",
            "audio_transcription",
        ],
    ):
        observables = {
            "complexity_proxy": data.get("metadata", {}).get("complexity_proxy", 0.5),
            "historical_route_success": data.get("metadata", {}).get("historical_route_success", 0.5),
            "risk_class": data.get("metadata", {}).get("risk_class", "standard"),
        }
        payload = {
            "spec_id": "OKD-AI-005",
            "adapter_type": "routing",
            "observables": observables,
            "context": {
                "messages_count": len(data.get("messages", [])),
                "requested_model": data.get("model"),
            },
            "history_state": {
                "recent_route": data.get("metadata", {}).get("recent_route", ""),
            },
            "resource_state": {
                "budget_remaining": data.get("metadata", {}).get("budget_remaining", 1.0),
                "latency_load_state": data.get("metadata", {}).get("latency_load_state", 0.5),
            },
            "policy_profile": {
                "profile_name": "default",
                "deterministic_mode": True,
            },
        }
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(
                f"{self.okada_base_url}/okada/route",
                json=payload,
                headers=self._headers(),
            )
            response.raise_for_status()
            route_decision = response.json()

        action = route_decision.get("recommended_action", "continue")
        if action in {"promote_strong_model", "bounded_hybrid"}:
            data["model"] = "strong-default"
        else:
            data["model"] = "cheap-default"

        metadata = data.setdefault("metadata", {})
        metadata["okada_regime"] = route_decision.get("regime")
        metadata["okada_audit_trace_id"] = route_decision.get("audit_trace_id")
        metadata["okada_action"] = action
        return data

    async def async_post_call_success_hook(
        self,
        data: dict,
        user_api_key_dict: UserAPIKeyAuth,
        response: Any,
    ) -> Any:
        audit_trace_id = data.get("metadata", {}).get("okada_audit_trace_id", "")
        if not audit_trace_id:
            return response

        audit_payload = {
            "audit_trace_id": audit_trace_id,
            "timestamp": "1970-01-01T00:00:00Z",
            "spec_id": "OKD-AI-005",
            "adapter_type": "routing",
            "raw_inputs": {
                "model": data.get("model"),
                "metadata": data.get("metadata", {}),
            },
            "normalized_inputs": {},
            "derived_features": {},
            "decision": {
                "regime": data.get("metadata", {}).get("okada_regime", "mixed"),
                "action": data.get("metadata", {}).get("okada_action", "continue"),
            },
            "alternatives": [],
            "policy_snapshot": {"profile_name": "default"},
        }

        async with httpx.AsyncClient(timeout=10.0) as client:
            try:
                await client.post(
                    f"{self.okada_base_url}/okada/audit",
                    json=audit_payload,
                    headers=self._headers(),
                )
            except Exception:
                # Audit shipping should not fail the model response path.
                pass
        return response
