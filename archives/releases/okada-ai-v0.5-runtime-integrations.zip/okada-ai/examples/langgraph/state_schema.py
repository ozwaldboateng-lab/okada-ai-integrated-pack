from __future__ import annotations

from typing import TypedDict, Literal


class AgentState(TypedDict, total=False):
    user_request: str
    plan: str
    tool_name: str
    tool_input: str
    tool_output: str
    planner_executor_mismatch: float
    tool_disagreement: float
    retry_count: int
    unresolved_subgoal_count: int
    route_split_frequency: float
    governance_action: str
    governance_regime: Literal["clean", "mixed", "contaminated"]
    audit_trace_id: str
