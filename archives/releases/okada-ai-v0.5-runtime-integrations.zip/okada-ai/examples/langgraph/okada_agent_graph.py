from __future__ import annotations

import os
from typing import Any

import httpx
from langgraph.graph import START, END, StateGraph
from langgraph.types import interrupt

from state_schema import AgentState


OKADA_BASE_URL = os.getenv("OKADA_BASE_URL", "http://localhost:8080")
OKADA_SHARED_TOKEN = os.getenv("OKADA_SHARED_TOKEN")


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if OKADA_SHARED_TOKEN:
        headers["Authorization"] = f"Bearer {OKADA_SHARED_TOKEN}"
    return headers


def plan_node(state: AgentState) -> AgentState:
    state["plan"] = f"Plan for: {state['user_request']}"
    state["tool_name"] = "search_docs"
    state["tool_input"] = state["user_request"]
    return state


def governance_node(state: AgentState) -> AgentState:
    payload = {
        "spec_id": "OKD-AI-003",
        "adapter_type": "agent",
        "observables": {
            "planner_executor_mismatch": state.get("planner_executor_mismatch", 0.0),
            "tool_disagreement": state.get("tool_disagreement", 0.0),
            "retry_count": state.get("retry_count", 0),
            "unresolved_subgoal_count": state.get("unresolved_subgoal_count", 0),
            "route_split_frequency": state.get("route_split_frequency", 0.0),
        },
        "context": {
            "user_request": state.get("user_request", ""),
            "plan": state.get("plan", ""),
            "tool_name": state.get("tool_name", ""),
        },
        "history_state": {},
        "resource_state": {},
        "policy_profile": {
            "profile_name": "default",
            "deterministic_mode": True,
        },
    }
    response = httpx.post(
        f"{OKADA_BASE_URL}/okada/intervene",
        json=payload,
        headers=_headers(),
        timeout=10.0,
    )
    response.raise_for_status()
    decision = response.json()
    state["governance_action"] = decision["recommended_action"]
    state["governance_regime"] = decision["regime"]
    state["audit_trace_id"] = decision["audit_trace_id"]

    if decision["recommended_action"] in {"human_handoff", "abort"}:
        human_decision = interrupt(
            {
                "message": "Okada governance requested review",
                "action": decision["recommended_action"],
                "regime": decision["regime"],
                "audit_trace_id": decision["audit_trace_id"],
            }
        )
        state["governance_action"] = human_decision.get("action", decision["recommended_action"])
    return state


def tool_node(state: AgentState) -> AgentState:
    state["tool_output"] = f"tool({state['tool_name']}) => result for {state['tool_input']}"
    return state


def final_node(state: AgentState) -> AgentState:
    state["final_answer"] = f"{state['plan']} | {state.get('tool_output', '')}"
    return state


def build_graph():
    graph = StateGraph(AgentState)
    graph.add_node("plan", plan_node)
    graph.add_node("governance_before_tool", governance_node)
    graph.add_node("tool", tool_node)
    graph.add_node("governance_after_tool", governance_node)
    graph.add_node("final", final_node)

    graph.add_edge(START, "plan")
    graph.add_edge("plan", "governance_before_tool")
    graph.add_edge("governance_before_tool", "tool")
    graph.add_edge("tool", "governance_after_tool")
    graph.add_edge("governance_after_tool", "final")
    graph.add_edge("final", END)
    return graph.compile()
