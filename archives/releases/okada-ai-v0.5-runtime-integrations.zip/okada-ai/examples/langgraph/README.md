# LangGraph Integration Example

LangGraph's interrupt mechanism is the recommended place for Okada agent governance.

This folder contains:
- `okada_agent_graph.py`: example graph with governance nodes
- `state_schema.py`: state contract
- `README.md`: usage notes

The example is intentionally small:
- plan
- governance check
- maybe interrupt
- tool step
- governance check
- final answer
