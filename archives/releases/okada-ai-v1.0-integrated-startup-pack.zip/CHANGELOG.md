## v0.9-openwebui-detailed
- Added Open WebUI detailed integration package with runtime helpers, Pipe/Filter examples, runbook, acceptance matrix, preflight script, and tests.

## v0.7.0
- added Dify detailed integration docs, runbook, acceptance matrix, and codegen prompt
- added Dify runtime helper module and tests
- added pre/post HTTP payload templates and code-node snippets
- added Dify preflight script and env example

# Changelog

## v0.6.0
- Added LiteLLM-focused runtime helpers for routing payload build, route mutation, and audit payload generation
- Added render_litellm_config.py and litellm_preflight.py
- Added deployable LiteLLM compose template and env example under ops/litellm/
- Added route_map.json and config template for callback-driven routing
- Added LiteLLM detailed design, runbook, acceptance matrix, and codegen prompt
- Added tests for LiteLLM runtime helpers

## v0.5.0
- Added runtime integration guide and acceptance test plan
- Added kernel Dockerfile and integration compose template
- Added Dify HTTP Request + Code node example pack
- Added LiteLLM proxy config and custom callback handler example
- Added LangGraph interrupt-based agent governance example
- Added Open WebUI Pipe and Filter examples
- Added runtime smoke fixtures and script
- Added auth-aware HTTP client and one extra test
