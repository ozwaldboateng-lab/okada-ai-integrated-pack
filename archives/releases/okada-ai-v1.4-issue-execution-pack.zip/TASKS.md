# TASKS.md

## Current suggested backlog

### High priority
- Tighten gateway contract validation across all `/integrations/*` endpoints
- Add richer benchmark fixtures for RAG stale/conflict cases
- Make LiteLLM route application reflect stronger `mixed` vs `contaminated` handling
- Improve LangGraph human-review roundtrip coverage
- Add operator-facing audit summary formatting

### Medium priority
- Expand acceptance matrices into executable checks
- Add schema versioning strategy
- Add baseline router implementations for more realistic comparisons

### Low priority
- Add second-wave adapter scaffolds beyond placeholders
- Package operator console examples more formally


# TASKS.md addendum: execution order

## Preferred first six tasks
1. TASK-KERNEL-001
2. TASK-LIT-001
3. TASK-DIFY-001
4. TASK-LANG-001
5. TASK-OWUI-001
6. TASK-E2E-001

## Then
- TASK-KERNEL-002
- TASK-BENCH-001
- TASK-E2E-002
- remaining packaging/docs tasks
