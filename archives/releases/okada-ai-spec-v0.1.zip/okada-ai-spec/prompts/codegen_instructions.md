# Codegen Instructions

## 目的
この仕様パックを読んで、Okada Governance Kernel と adapter 群の雛形実装を生成する。

## 優先順位
1. `registry/` を source of truth とする
2. `api/` の OpenAPI を優先して server stub を作る
3. `schemas/` で validation を作る
4. `fixtures/` をもとに最低限の unit test / regression test を作る
5. `docs/` は意味論確認に使う

## 生成物
- backend service skeleton
- adapter interfaces
- routing / rag / agent middleware stubs
- audit logger
- config objects / enums
- test scaffolding

## 実装原則
- deterministic mode を持つ
- 各判定で audit payload を必ず作る
- `H_dom`, `H_hist`, `H_comp`, `V_first`, `R_diag` を共通インターフェースに含める
- 閾値は config に逃がす
- domain-specific logic は adapter に閉じ込める

## 禁止
- spec にない新概念の勝手な追加
- foundation model training の実装
- benchmark 条件を勝手に変更すること
