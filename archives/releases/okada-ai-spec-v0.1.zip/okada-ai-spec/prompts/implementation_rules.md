# Implementation Rules

## 共通ルール
- すべての adapter は Core interface を継承する
- すべての判定は AuditRecord を返せること
- raw_inputs と normalized_inputs を分けて扱うこと
- 閾値と重みは config 化すること
- まずは if/score ベースでよいが feature 名は固定すること

## 推奨言語構成
- backend: Python or TypeScript
- schemas: JSON Schema
- API: OpenAPI
- tests: pytest or vitest/jest

## 生成優先順
1. Core models / enums
2. API handlers
3. Audit logger
4. Adapter skeletons
5. Dify / LiteLLM / LangGraph integration stubs
6. Fixture-driven tests
