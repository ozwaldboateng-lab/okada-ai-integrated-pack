# CHANGELOG

## 0.1 - 2026-04-17
- 概要設計書を追加
- アーキテクチャ文書を追加
- OSS統合マップを追加
- 用語集を追加
- 仕様レジストリを追加
- Core仕様と First Wave 5本の adapter 仕様を追加
- OpenAPI 定義草案を追加
- JSON Schema 草案を追加
- fixture 用 JSONL ケースを追加
- コード生成AI向け instructions を追加
