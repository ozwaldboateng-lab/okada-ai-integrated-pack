# アーキテクチャ設計メモ

## 1. アーキテクチャ原理
- 共通カーネル + domain adapter
- 外付けサービス優先
- 監査ログ中心
- ベースライン比較可能性を維持

## 2. 主要レイヤ
### 2.1 Presentation
- Dify App UI
- Open WebUI
- Operator Dashboard

### 2.2 Orchestration
- Dify Workflow / Chatflow
- LangGraph Graph Runtime
- External Job Runner

### 2.3 Governance
- Okada Governance Kernel
- Adapter Modules
- Policy Evaluator
- Intervention Planner
- Audit Writer

### 2.4 Model Gateway
- LiteLLM Proxy
- Routing Hooks
- Fallback Policy
- Cost / Latency Metrics

### 2.5 Data / Knowledge
- Knowledge store
- Vector index
- Session history
- Route history
- Audit log store
- Metrics / observability store

## 3. データフロー
### 3.1 RAG
query
-> pre-retrieval governance
-> retrieval
-> post-retrieval governance
-> answer draft
-> final governance
-> output
-> audit

### 3.2 Agent
task
-> planning
-> governance
-> tool selection
-> governance
-> tool execution
-> governance
-> answer
-> audit

### 3.3 Routing
request
-> LiteLLM pre-hook
-> route decision
-> model call
-> post-call audit

## 4. システム境界
### 4.1 Kernel が持つもの
- feature derivation
- regime classification
- action suggestion
- audit payload generation

### 4.2 Adapter が持つもの
- observable dictionary
- normalization rules
- domain-specific features
- baseline mapping

### 4.3 OSS 側が持つもの
- app shell
- workflow execution
- model serving
- human interaction
- dashboard

## 5. 配置原則
- Dify: app / RAG / branching
- LiteLLM: routing chokepoint
- LangGraph: long-horizon agent control
- Open WebUI: operator console
- Okada Kernel: shared external intelligence layer

## 6. 監査原則
最低限保存すべき要素:
- raw_inputs
- normalized_inputs
- H_dom
- H_hist
- H_comp
- V_first
- R_diag
- regime
- selected_action
- alternatives
- caller
- timestamp
- trace_id

## 7. 実装原則
- fork は初期禁止
- extension point / external call を優先
- benchmark を壊さない
- policy profile を切り替え可能にする
