# 岡田理論統合AIプラットフォーム 概要設計書

- Document ID: OAI-AD-001
- Version: 0.1
- Status: Draft

## 1. 目的
本システムの目的は、**既存のオープンソースAI基盤の上に岡田理論レイヤーを付加し、同一のモデル群・同一の知識源・同一の予算制約の下で、既存構成より高い end-to-end performance を示すAIシステムを構築すること**である。

ここでいう性能向上は、基盤モデル単体の知能向上ではなく、AIシステム全体としての以下の改善を指す。

- task success の向上
- 不要な retrieval / tool call / heavy model call の削減
- contaminated 状態の早期検知
- escalation / rollback / abstain の適切化
- 同品質でのコスト・レイテンシ削減
- 同コストでの品質向上

## 2. 設計方針
本システムは、新しい基盤モデルを訓練するものではない。設計方針は、**既存AI基盤の上に載る上位診断・統御層**として岡田理論を実装することである。

### 2.1 共通カーネル方式
岡田理論を各問題ごとに別実装するのではなく、共通の **Okada Governance Kernel** を中核に置き、その上に問題領域ごとの adapter を載せる。

### 2.2 既存OSS活用方式
既存のオープンソース基盤を活用し、最小改造で実現する。初期段階では fork を避け、extension point と外部サービス連携を優先する。

### 2.3 実装対象の限定
本システムは、以下の機能を主対象とする。
- RAG 統御
- multi-model routing
- agentic AI governance
- post-deployment monitoring
- MLOps drift intervention

### 2.4 監査可能性重視
すべての判定は、単一のスコア出力で終わらせず、**dominant route / retained history / competitor pressure / first visible handle** の分解を監査ログとして保持する。

## 3. システム化対象
### 3.1 First Wave
- Post-deployment Monitoring / Trust Window Governance
- MLOps Concept Drift Thresholding
- Agentic AI Route Contamination and Escalation Governance
- RAG Freshness / Context Contamination Governance
- Multi-model / Multi-strategy Routing Governance

### 3.2 Second Wave
- Industrial Anomaly Warning Layer
- Root-cause Prioritization Pre-layer
- Evaluation Contamination / Judge Leakage Auditor
- Inference-era Datacenter Energy / Latency Governance
- Quantum Optimization Diagnosis-driven Governance

### 3.3 Hold
- Drift-aware Intrusion Detection Governance
- Mitigation-to-Correction Handoff Governance

## 4. システムの全体像
本システムは、既存OSSと外部カーネルを組み合わせた統合構成を採る。

### 4.1 全体構成
- **Dify**: アプリ本体、RAG、ワークフロー、分岐制御
- **LiteLLM**: モデル呼び出しゲートウェイ、routing、model policy enforcement
- **LangGraph**: 長い agent 実行の制御、中断、再開、human handoff
- **Open WebUI**: 運用UI、手動検証、評価、監査確認
- **Okada Governance Kernel**: 岡田理論に基づく判定・統御の外部中核サービス

### 4.2 構成の要点
Dify は「AIアプリの殻」として機能し、LiteLLM は「モデル呼び出しの関所」として機能する。LangGraph は agent 的な長い処理の制御器であり、Open WebUI は運用・監査用の顔となる。岡田理論の本体は、これら各基盤の内部に分散実装せず、**外部の共通 Kernel service** として一元化する。

## 5. 論理アーキテクチャ
### 5.1 Presentation Layer
- Dify App UI
- Open WebUI
- 運用者用 dashboard
- 監査表示画面

### 5.2 Orchestration Layer
- Dify Workflow / Chatflow
- LangGraph Graph Runtime
- 各 adapter 呼び出しフロー

### 5.3 Governance Layer
- Okada Governance Kernel
- domain adapter
- rule evaluator
- intervention planner
- audit generator

### 5.4 Model Gateway Layer
- LiteLLM Proxy
- model selection
- fallback
- policy hooks
- cost / latency / usage collection

### 5.5 Data / Knowledge Layer
- Dify Knowledge
- vector store / corpus index
- session history
- route history
- audit log storage
- observability storage

## 6. 中核コンポーネント設計
### 6.1 Okada Governance Kernel
#### 目的
全領域共通の診断・統御文法を提供する。

#### 主責務
- 観測量正規化
- 岡田特徴量生成
- regime 判定
- action 推奨
- audit trace 生成

#### 共通特徴量
- `H_dom`: dominant route score
- `H_hist`: retained history / load score
- `H_comp`: competitor pressure score
- `V_first`: first visible handle
- `R_diag`: 分解比
- `S_trust`: trust / viability score
- `regime`: clean / mixed / contaminated
- `type_class`: I / II / III / undefined

### 6.2 Domain Adapters
- Monitoring Adapter
- Drift Adapter
- Agent Adapter
- RAG Adapter
- Routing Adapter

### 6.3 Audit Service
#### 保存対象
- raw inputs
- normalized inputs
- derived features
- regime decision
- selected action
- rejected alternatives
- calling component
- timestamp
- session/request identifiers

## 7. OSS別責務分担
### 7.1 Dify
- アプリUI
- RAGワークフロー
- 分岐制御
- API backend
- Code Node 経由で Okada Kernel を呼ぶ

### 7.2 LiteLLM
- モデル呼び出し統一
- pre-call / post-call policy hook
- model routing
- fallback
- usage / cost / latency 計測

### 7.3 LangGraph
- stateful agent runtime
- interrupt
- human handoff
- persistence
- stepwise governance insertion

### 7.4 Open WebUI
- 運用者UI
- 手動評価
- 監査確認
- route policy の可視化
- human review の入口

## 8. 処理方式
### 8.1 基本フロー
1. アプリまたは workflow が処理を開始する
2. 必要に応じて Dify / LangGraph / LiteLLM が Okada Kernel を呼ぶ
3. Kernel が observables を受け取り、岡田特徴量を計算する
4. regime と action を返す
5. 呼び出し元がその action に従って処理を分岐・制御する
6. 同時に audit record を保存する

### 8.2 代表例
#### RAG系
質問受付 → retrieval 要否判定 → retrieve → contamination 判定 → deeper retrieve / rerank / abstain → answer → audit

#### Agent系
plan 作成 → governance check → tool 選択前 check → tool 実行 → result 後 check → re-plan / handoff / continue → final answer → audit

#### Routing系
query 受付 → LiteLLM pre-hook → Okada route 判定 → selected model / strategy 呼び出し → post-call route audit

## 9. インターフェース概要
### 9.1 外部API
- `POST /okada/diagnose`
- `POST /okada/route`
- `POST /okada/intervene`
- `POST /okada/audit`

### 9.2 入力の基本構造
- `spec_id`
- `adapter_type`
- `observables`
- `context`
- `history_state`
- `resource_state`
- `policy_profile`

### 9.3 出力の基本構造
- `regime`
- `type_class`
- `scores`
- `first_visible_handle`
- `recommended_action`
- `alternatives`
- `audit_trace_id`

## 10. データ設計方針
### 10.1 データ分類
- 運用観測データ
- 知識データ
- ルーティング履歴
- 監査データ

### 10.2 保存原則
- 生観測値と正規化後値を分けて保存
- 最終判定だけでなく中間分解も保存
- domain adapter ごとの追加特徴量も許容
- 監査ログは共通 schema を持つ

## 11. 非機能要件
- 説明可能性
- 一貫性
- 低侵襲性
- 拡張性
- 監査容易性
- 比較可能性

## 12. ベースライン比較設計方針
固定するもの:
- モデルプール
- 知識源
- 使用可能ツール
- 予算制約
- 実行回数
- benchmark セット

変えるもの:
- 岡田理論レイヤーの有無

主な比較対象:
- fixed strongest model
- fixed cheapest model
- cost-only router
- heuristic fallback
- always retrieve
- top-k fixed retrieval
- retry-threshold-only agent governance
- threshold-only monitoring

主評価軸:
- task success
- cost per success
- p95 latency
- retrieval / tool call waste
- stale answer reduction
- catastrophic failure reduction
- false rollback / false retrain reduction

## 13. フェーズ構成
### 13.1 Phase 1
- Okada Governance Kernel 実装
- Dify + LiteLLM + LangGraph + Open WebUI 接続
- first wave 001〜005 を最小実装

### 13.2 Phase 2
- second wave adapter 追加
- 運用監査UI強化
- benchmark automation

### 13.3 Phase 3
- adaptive calibration
- policy profile 複数化
- domain-specific tuning
- publication package 作成

## 14. 主要リスク
- 理論の空文化
- 保守性低下
- 過剰保守性
- 評価設計の曖昧化

## 15. 今後の詳細化対象
- 詳細設計書
- OSS実装部位設計
- benchmark 設計書

## 16. 結論
本システムは、岡田理論を単独の万能AIとして実装するものではない。**既存AI基盤の上位に載る共通診断・統御カーネルとして実装し、RAG・routing・agent・monitoring など複数領域を一つの文法で統御するAIプラットフォーム**として構成する。
