# Okada AI Specification Pack

Version: 0.1  
Status: Draft  
Date: 2026-04-17

## 目的
このリポジトリは、岡田理論を既存AI基盤の上位診断・統御レイヤーとして実装するための、
**概要設計・仕様レジストリ・API定義・スキーマ・評価fixture** をまとめた仕様パックです。

このパックは次を満たすことを狙います。

- 人間が読める
- コード生成AIが分解しやすい
- 差分管理しやすい
- 後で詳細設計・実装・評価へ伸ばしやすい

## source of truth
- 構造化された仕様定義: `registry/`
- 人間向け説明文書: `docs/`
- API定義: `api/`
- バリデーション用スキーマ: `schemas/`
- 例題・回帰テスト素材: `fixtures/`

## 推奨利用順
1. `docs/00_overview_design.md` を読む
2. `registry/spec_registry.yaml` で全体一覧を把握する
3. 個別仕様は `registry/core/` と `registry/adapters/` を読む
4. 実装は `api/okada-governance.openapi.yaml` と `schemas/` を参照する
5. テスト・比較は `fixtures/*.jsonl` を参照する

## ディレクトリ構成
```text
okada-ai-spec/
├─ README.md
├─ CHANGELOG.md
├─ docs/
├─ registry/
├─ api/
├─ schemas/
├─ fixtures/
└─ prompts/
```

## 注意
- 本パックは論文ではなく仕様資産です。
- 閾値 `T_*` と重み `W_*` は暫定の識別子であり、後段で校正します。
- まずは意味論・責務分担・入出力を固定することを優先しています。
