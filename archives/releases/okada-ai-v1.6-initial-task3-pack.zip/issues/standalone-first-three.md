# Standalone First Three Tasks

このノートは、issue 分担ではなく **同一 task を独立に実装する** 用の入口である。

参照先:
- `docs/64_initial_three_tasks_bundle.md`
- `standalone/initial-three-tasks.yaml`
- `standalone/task-bundles/*.md`
