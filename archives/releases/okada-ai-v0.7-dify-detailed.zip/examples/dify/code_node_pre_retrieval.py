def main(okada_response: dict) -> dict:
    scores = okada_response.get("scores", {})
    action = okada_response.get("recommended_action", "standard_retrieve")
    return {
        "okada_regime": okada_response.get("regime", "mixed"),
        "okada_trust_state": okada_response.get("trust_state", "undefined"),
        "okada_recommended_action": action,
        "okada_retrieval_action": action,
        "okada_should_retrieve": action in {"standard_retrieve", "deeper_retrieve", "rerank_again", "require_fresh_source"},
        "okada_should_abstain": action == "abstain",
        "okada_deeper_retrieve": action == "deeper_retrieve",
        "okada_audit_trace_id": okada_response.get("audit_trace_id", ""),
        "okada_context_contamination_score": float(scores.get("context_contamination_score", 0.0)),
        "okada_freshness_gap_score": float(scores.get("freshness_gap_score", 0.0)),
        "okada_governance_available": True,
    }
