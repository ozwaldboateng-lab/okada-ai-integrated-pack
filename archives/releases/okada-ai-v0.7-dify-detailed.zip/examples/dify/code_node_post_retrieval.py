def main(okada_response: dict) -> dict:
    scores = okada_response.get("scores", {})
    action = okada_response.get("recommended_action", "continue")
    return {
        "okada_regime": okada_response.get("regime", "mixed"),
        "okada_final_action": action,
        "okada_require_fresh_source": action == "require_fresh_source",
        "okada_rerank_again": action == "rerank_again",
        "okada_should_abstain": action == "abstain",
        "okada_audit_trace_id": okada_response.get("audit_trace_id", ""),
        "okada_context_contamination_score": float(scores.get("context_contamination_score", 0.0)),
        "okada_freshness_gap_score": float(scores.get("freshness_gap_score", 0.0)),
        "okada_governance_available": True,
    }
