# Dual Agent Handoff

This repository can be handed to both Codex and Claude Code.
The default recommended mode is **standalone comparison**, not role division.

See:
- `docs/61_dual_standalone_usage.md`
- `docs/62_human_comparison_checklist.md`
- `docs/63_dual_standalone_runbook.md`
