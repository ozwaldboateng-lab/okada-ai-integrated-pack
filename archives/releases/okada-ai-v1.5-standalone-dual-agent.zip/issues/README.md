# Issues Directory

This directory is optional support material.

The current recommended operating mode for the repository is **standalone comparison**:
- Codex can take a task from here in one repo copy
- Claude Code can take the same task in another repo copy
- the results can then be compared by eye

This directory does **not** imply subsystem role ownership by default.
