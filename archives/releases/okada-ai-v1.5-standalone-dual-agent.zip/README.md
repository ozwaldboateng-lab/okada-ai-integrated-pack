# Okada AI Kernel Service

This repository is a specification-driven implementation scaffold for the **Okada Governance Kernel**.
It is designed to be usable by both **Codex** and **Claude Code**.

## Intended usage mode
This repository is currently organized for **standalone parallel implementation**.
That means:
- Codex can work on a task in its own copy of the repo.
- Claude Code can work on the same task in a separate copy of the repo.
- The outputs can then be compared by eye.
- Strict merge choreography is **not** required by default.

## What is included
- FastAPI service for `/okada/diagnose`, `/okada/route`, `/okada/intervene`, `/okada/audit`, `/healthz`
- integration gateway endpoints under `/integrations/*`
- source-of-truth specs under `specs/okada-ai-spec/`
- adapter stubs for monitoring / drift / agent / rag / routing
- JSONL-backed audit persistence
- runtime integration examples for Dify / LiteLLM / LangGraph / Open WebUI
- smoke tests and fixture loading scripts
- prompts and handoff files for Codex / Claude Code

## Important limitations
This is still not the final calibrated system.
Thresholds and weights remain placeholders.
The goal of this pack is to provide:
- stable interfaces
- executable kernel service
- concrete runtime integration templates
- code-generation-ready handoff material

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
uvicorn app.main:app --app-dir apps/okada-kernel-service --reload --port 8080
```

## Run tests
```bash
pytest apps/okada-kernel-service/tests -q
```

## Suggested standalone comparison flow
1. Unzip or clone the repository twice.
2. Give the same task and acceptance criteria to Codex and Claude Code separately.
3. Let each tool modify only its own copy.
4. Run tests in each copy.
5. Compare the outputs and tool behavior by eye.

See:
- `docs/61_dual_standalone_usage.md`
- `docs/62_human_comparison_checklist.md`
- `prompts/codex_start_prompt.md`
- `prompts/claude_code_start_prompt.md`

## Runtime integration quick map
- `examples/dify/`: Dify HTTP Request + Code Node integration examples
- `examples/litellm/`: LiteLLM Proxy custom pre/post hook examples
- `examples/langgraph/`: LangGraph interrupt-driven governance example
- `examples/openwebui/`: Open WebUI Pipe / Filter examples

## Repository layout
- `apps/okada-kernel-service/`: service implementation
- `specs/okada-ai-spec/`: source-of-truth specification pack
- `examples/`: runtime integration examples
- `scripts/`: validation and smoke utilities
- `ops/`: deployment and environment examples
- `issues/`: optional task index; may be used by either tool independently

## Agent-facing files
- `AGENTS.md`: shared operating contract
- `CLAUDE.md`: Claude Code oriented repo instructions
- `TASKS.md`: suggested starting tasks
- `prompts/`: start prompts and shared handoff prompts
