# Okada AI Kernel Service (Bootstrap)

This repository is the initial implementation skeleton for the Okada Governance Kernel.

## What is included
- FastAPI service for `/okada/diagnose`, `/okada/route`, `/okada/intervene`, `/okada/audit`, `/healthz`
- Source-of-truth specs under `specs/okada-ai-spec/`
- Adapter stubs for monitoring / drift / agent / rag / routing
- JSONL-backed audit persistence
- Integration stubs for Dify / LiteLLM / LangGraph / Open WebUI
- Smoke tests and fixture loading script

## Important limitations
This is a **bootstrap implementation**, not the final calibrated system.
Thresholds and weights remain placeholders. The service is intended to provide:
- stable interfaces
- auditable feature decomposition
- deterministic stub behavior
- a concrete base for code-generation AI or manual extension

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
uvicorn app.main:app --app-dir apps/okada-kernel-service --reload --port 8080
```

## Run tests
```bash
pytest apps/okada-kernel-service/tests -q
```

## Repository layout
- `apps/okada-kernel-service/`: service implementation
- `specs/okada-ai-spec/`: source-of-truth specification pack
- `examples/`: integration examples
- `scripts/`: validation and smoke utilities
