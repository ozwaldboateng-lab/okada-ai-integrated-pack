# LangGraph integration stub

Suggested insertion points:
- after planner
- before tool execution
- after tool result
- before final answer
