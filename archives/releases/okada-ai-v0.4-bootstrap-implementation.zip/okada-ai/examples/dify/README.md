# Dify integration stub

Suggested insertion points:
1. Query intake -> call `/okada/diagnose` for RAG governance
2. Post-retrieval -> call `/okada/intervene` before answer generation
3. Workflow end -> call `/okada/diagnose` for trust window update
