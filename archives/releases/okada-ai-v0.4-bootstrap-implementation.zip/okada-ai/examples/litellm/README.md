# LiteLLM integration stub

Suggested insertion point:
- Pre-call routing hook -> call `/okada/route`
- Post-call audit -> call `/okada/audit` or rely on kernel persistence
