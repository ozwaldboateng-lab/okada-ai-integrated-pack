# Open WebUI integration stub

Suggested usage:
- expose recent audits via `/okada/audit`
- operator review panel for human handoff or abstention cases
