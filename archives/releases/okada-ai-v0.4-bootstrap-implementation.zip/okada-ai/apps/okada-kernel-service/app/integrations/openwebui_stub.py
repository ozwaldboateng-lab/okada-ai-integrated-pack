from __future__ import annotations

import httpx


def fetch_recent_audits(base_url: str = "http://localhost:8080") -> list[dict]:
    response = httpx.get(f"{base_url.rstrip('/')}/okada/audit")
    response.raise_for_status()
    return response.json()
