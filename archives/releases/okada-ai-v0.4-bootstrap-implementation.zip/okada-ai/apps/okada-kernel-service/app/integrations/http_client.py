from __future__ import annotations

import httpx

from app.models.contracts import DiagnoseRequest, DiagnoseResponse


class OkadaHttpClient:
    def __init__(self, base_url: str = "http://localhost:8080") -> None:
        self.base_url = base_url.rstrip("/")

    def diagnose(self, request: DiagnoseRequest) -> DiagnoseResponse:
        response = httpx.post(f"{self.base_url}/okada/diagnose", json=request.model_dump())
        response.raise_for_status()
        return DiagnoseResponse.model_validate(response.json())

    def route(self, request: DiagnoseRequest) -> DiagnoseResponse:
        response = httpx.post(f"{self.base_url}/okada/route", json=request.model_dump())
        response.raise_for_status()
        return DiagnoseResponse.model_validate(response.json())

    def intervene(self, request: DiagnoseRequest) -> DiagnoseResponse:
        response = httpx.post(f"{self.base_url}/okada/intervene", json=request.model_dump())
        response.raise_for_status()
        return DiagnoseResponse.model_validate(response.json())
