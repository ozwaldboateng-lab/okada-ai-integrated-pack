from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    audit_dir: Path
    default_policy: str
    service_port: int

    @classmethod
    def from_env(cls) -> "Settings":
        audit_dir = Path(os.getenv("OKADA_AUDIT_DIR", "./data/audit"))
        default_policy = os.getenv("OKADA_DEFAULT_POLICY", "default")
        service_port = int(os.getenv("OKADA_SERVICE_PORT", "8080"))
        return cls(audit_dir=audit_dir, default_policy=default_policy, service_port=service_port)


settings = Settings.from_env()
settings.audit_dir.mkdir(parents=True, exist_ok=True)
