# LangGraph Acceptance Matrix

| Scenario | Expected Regime | Expected Action | Expected Graph Effect |
|---|---|---|---|
| clean task | clean | continue | tool executes, final answer emitted |
| mild mismatch | mixed | constrained_continue | tool executes under restricted policy |
| growing contradiction | mixed | replan | graph branches to replan node |
| severe conflict | contaminated | human_handoff | interrupt fired |
| unsafe task | contaminated | abort | graph terminates before final tool action |

## Minimum acceptance conditions
- interrupt path works with preserved `audit_trace_id`
- replan branch is reachable and resumable
- abort does not emit unsafe tool action
- post-tool governance can still override earlier decisions
