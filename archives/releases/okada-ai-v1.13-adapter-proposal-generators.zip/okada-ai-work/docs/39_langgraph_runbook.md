# LangGraph Runbook

## Preconditions
- Okada Kernel service running
- `OKADA_BASE_URL` configured
- `OKADA_SHARED_TOKEN` configured if auth is enabled
- LangGraph runtime installed in the consuming application
- checkpointer enabled

## Local smoke flow
1. start the kernel service
2. set `OKADA_BASE_URL`
3. run the example graph with a thread config
4. trigger a case that returns `human_handoff`
5. resume with a reviewer action payload
6. confirm the final state and audit trace

## Failure modes
- kernel timeout -> fail closed or fail safe depending on policy profile
- missing thread id -> no durable interrupt/resume
- repeated replans -> cap by remaining step budget
- reviewer silence -> timeout to abort or restricted continue

## Operational checks
- interrupt path exercised at least once in smoke tests
- audit trace id preserved before and after human review
- tool policy restrictions visible in state
