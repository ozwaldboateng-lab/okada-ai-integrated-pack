# Parallel worktree strategy

## Purpose
This document defines a safe way to let multiple coding agents work on the repository in parallel.

## Principle
Split work by boundary, not by random file ownership.

## Recommended parallel lanes
### Lane A: Kernel/API
- FastAPI endpoints
- pydantic models
- schemas
- audit persistence

### Lane B: LiteLLM + routing
- `examples/litellm/`
- `app/integrations/*litellm*`
- routing fixtures/tests

### Lane C: Dify + RAG
- `examples/dify/`
- RAG adapter behavior
- stale/conflict fixtures/tests

### Lane D: LangGraph + agent governance
- `examples/langgraph/`
- agent step/handoff logic
- agent fixtures/tests

### Lane E: Open WebUI + operator console
- `examples/openwebui/`
- audit/console docs
- operator-facing payload shaping

## Merge rule
Before merging a lane:
- re-run tests
- ensure docs for affected adapter are updated
- ensure audit fields still contain decomposition

## Avoid parallelizing across these boundaries
Do not let two agents freely modify:
- shared request/response models
- gateway contract payloads
- same fixture files
- same acceptance matrix files

unless one agent is explicitly designated as integration lead.
