# Gateway-unified Examples

All OSS-side examples should call the integration gateway rather than kernel core endpoints.

Stable endpoint families:
- LiteLLM: `/integrations/litellm/*`
- Dify: `/integrations/dify/*`
- LangGraph: `/integrations/langgraph/*`
- Open WebUI: `/integrations/openwebui/*`
