# Open WebUI Runbook

## 1. Environment
Set:
- `OKADA_BASE_URL`
- `OKADA_SHARED_TOKEN`
- optional model ids for Pipe configuration

## 2. Install sequence
1. Start the Okada kernel service.
2. Confirm `/healthz` is healthy.
3. Register Pipe and Filter into Open WebUI.
4. Apply metadata fields to the operator UI.
5. Run smoke conversation tests.

## 3. Smoke checks
- Low-risk prompt chooses cheap model.
- High-complexity prompt can promote to strong model.
- Filter metadata appears on the request.
- Contaminated blocking works when enabled.
- Fail-safe metadata appears when kernel is unavailable.

## 4. Operational checks
- Inspect `okada_audit_trace_id` for each routed request.
- Confirm operators can identify why the system chose a route.
- Confirm no request is silently dropped by the filter.

## 5. Rollback
If the integration causes UI issues:
- disable the Filter first
- keep the Pipe disabled until metadata issues are fixed
- fall back to standard Open WebUI routing
