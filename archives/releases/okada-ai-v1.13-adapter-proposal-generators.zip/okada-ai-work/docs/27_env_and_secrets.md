# Environment and Secrets

## Core kernel service
Required:
- `OKADA_AUDIT_PATH`
- `OKADA_DEFAULT_PROFILE`
- `OKADA_SERVICE_NAME`

Optional:
- `OKADA_REQUIRE_AUTH`
- `OKADA_SHARED_TOKEN`

## Dify
Store in Dify secrets or environment:
- `OKADA_BASE_URL`
- `OKADA_SHARED_TOKEN`

## LiteLLM
Store in proxy environment:
- `OKADA_BASE_URL`
- `OKADA_SHARED_TOKEN`

## LangGraph
Store in agent runtime environment:
- `OKADA_BASE_URL`
- `OKADA_SHARED_TOKEN`
- `LANGGRAPH_THREAD_PREFIX`

## Open WebUI
Store as pipe/filter valves or server env:
- `OKADA_BASE_URL`
- `OKADA_SHARED_TOKEN`

## Secret handling rule
Never hardcode API tokens into workflow exports, plugin files, or prompt packs.
