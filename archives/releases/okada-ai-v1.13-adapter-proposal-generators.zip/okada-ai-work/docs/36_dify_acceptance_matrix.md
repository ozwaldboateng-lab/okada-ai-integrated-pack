# Dify Acceptance Matrix

| Scenario | Input Condition | Expected Governance Output | Expected Dify Branch |
|---|---|---|---|
| Clean RAG | Fresh sources, low conflict, good grounding | `regime=clean`, `action=continue` or `standard_retrieve` | normal retrieval / answer |
| Stale Corpus | High `index_age`, low freshness, time-sensitive query | `regime=mixed`, `action=deeper_retrieve` or `require_fresh_source` | deep retrieval or fresh-source branch |
| Contradictory Sources | Multiple conflicting chunks | `regime=mixed/contaminated`, `action=rerank_again` or `abstain` | rerank or abstain |
| Weak Grounding | Low grounding confidence after retrieval | `regime=contaminated`, `action=abstain` | abstain response |
| Kernel Down | HTTP failure / timeout | `governance_available=false` | fail-safe retrieval or baseline answer |

## Minimum acceptance
The integration passes when all five cases are manually reproducible and the chosen branches match the matrix.
