# 31. LiteLLM Runbook

## Local run order
1. Copy `ops/litellm/.env.example` to `.env` in the same directory and fill values.
2. Start the kernel service.
3. Run `python scripts/litellm_preflight.py`.
4. Render config with `python scripts/render_litellm_config.py --template examples/litellm/proxy_config.template.yaml --output /tmp/litellm.config.yaml`.
5. Start LiteLLM using the rendered config.
6. Send a request with metadata.

## Minimal smoke request requirements
The request should include a `metadata` object with at least:
- `complexity_proxy`
- `budget_remaining`
- `historical_route_success`

## Expected first success signal
- LiteLLM returns a model response.
- Request metadata is enriched with `okada_*` keys.
- Kernel audit store receives an audit record.

## First things to inspect if routing looks wrong
- route map JSON
- metadata values actually present at request time
- kernel `/healthz`
- kernel `/okada/route` direct response for the same payload


## Import path note
Set `PYTHONPATH` so the callback can import `app.*` from `apps/okada-kernel-service`.
