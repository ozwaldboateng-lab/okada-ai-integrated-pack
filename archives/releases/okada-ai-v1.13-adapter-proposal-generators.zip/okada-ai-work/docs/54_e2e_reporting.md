# 54. E2E Reporting

## Current state
The repository includes a lightweight fixture-based benchmark harness and summary file.

## Reporting loop
1. Run `python scripts/e2e_compare.py --pretty`.
2. Archive the generated JSON summary.
3. Run `python scripts/dev_status.py` for a condensed operator report.
4. Compare the Okada summary against the baseline before changing policy thresholds.
