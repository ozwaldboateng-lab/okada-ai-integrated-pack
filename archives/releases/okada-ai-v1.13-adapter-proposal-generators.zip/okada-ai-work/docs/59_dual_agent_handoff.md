# Dual-agent handoff guide (Codex + Claude Code)

## Goal
This repository is packaged so that either Codex-style coding agents or Claude Code-style coding agents can continue development with minimal reformatting.

## Shared entrypoint
Both agents should start from the same source-of-truth hierarchy:
1. registry YAML
2. API/schema files
3. architecture/design docs
4. code
5. examples

## Shared operating rules
- work task-by-task, not repo-wide rewrites
- preserve the Okada decomposition in every meaningful interface
- keep OSS-specific glue code thin
- favor benchmarkable improvements over speculative redesign
- update docs + tests together when behavior changes

## Recommended first task categories
1. API/schema hardening
2. realistic adapter behavior
3. gateway integration completion
4. benchmark fixture enrichment
5. operator/audit workflow refinement

## Packaging conventions that help both agents
- plain text docs (`.md`)
- structured registry (`.yaml`)
- schemas (`.json`, OpenAPI YAML)
- fixtures (`.jsonl`)
- explicit runbooks

## Human oversight points
A human should still decide:
- what counts as a “win” on the next benchmark
- threshold/weight calibration strategy
- which integration is next in priority
- which domain adapter enters production first
