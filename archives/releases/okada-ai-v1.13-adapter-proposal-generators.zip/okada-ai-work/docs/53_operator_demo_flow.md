# 53. Operator Demo Flow

## Goal
Demonstrate one end-to-end narrative for each major integration.

## Suggested demo order
1. LiteLLM pre-route: show promotion from cheap model to stronger route.
2. Dify RAG post-retrieval: show stale/conflicting evidence producing deeper retrieval or freshness-aware handling.
3. LangGraph step governance: show interrupt or constrained tool policy on a risky action.
4. Open WebUI filter: show trust-window style audit metadata attached to operator-visible payload.

## Success condition
The operator can show:
- regime
- recommended action
- transformed platform payload
- audit payload or trace ID
