from __future__ import annotations

import json
import os
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
PAYLOAD_PRE = ROOT / "examples" / "dify" / "http_request_payload_pre.json"


def render_template_placeholders(obj):
    if isinstance(obj, dict):
        return {k: render_template_placeholders(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [render_template_placeholders(v) for v in obj]
    if isinstance(obj, str) and "{{#" in obj:
        return 0.5
    return obj


def main() -> int:
    base_url = os.getenv("OKADA_BASE_URL", "http://localhost:8080").rstrip("/")
    token = os.getenv("OKADA_SHARED_TOKEN", "")
    with PAYLOAD_PRE.open("r", encoding="utf-8") as fh:
        payload = json.load(fh)
    payload = render_template_placeholders(payload)
    payload["context"]["user_query"] = "preflight"
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    try:
        response = httpx.post(f"{base_url}/okada/diagnose", json=payload, headers=headers, timeout=10.0)
        response.raise_for_status()
    except Exception as exc:
        print(f"Dify preflight failed: {exc}")
        return 1

    data = response.json()
    print("Dify preflight succeeded.")
    print(f"regime={data.get('regime')} action={data.get('recommended_action')} audit={data.get('audit_trace_id')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
