from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

REQUIRED_ENV = [
    "OKADA_BASE_URL",
    "OPENAI_API_BASE",
    "OPENAI_API_KEY",
    "LITELLM_MASTER_KEY",
    "CHEAP_MODEL_NAME",
    "STRONG_MODEL_NAME",
]


def check_env() -> list[str]:
    return [key for key in REQUIRED_ENV if not os.getenv(key)]


def check_kernel(base_url: str) -> tuple[bool, str]:
    try:
        with urllib.request.urlopen(f"{base_url.rstrip('/')}/healthz", timeout=5) as response:
            body = json.loads(response.read().decode("utf-8"))
            return bool(body.get("status") == "ok"), json.dumps(body)
    except urllib.error.URLError as exc:
        return False, str(exc)


def check_route_map(path: str | None) -> tuple[bool, str]:
    if not path:
        return True, "No route map path set; default in-code mapping will be used"
    route_map = Path(path)
    if not route_map.exists():
        return False, f"Route map does not exist: {route_map}"
    try:
        content = json.loads(route_map.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return False, f"Invalid JSON route map: {exc}"
    return isinstance(content, dict), f"Loaded {len(content) if isinstance(content, dict) else 0} route entries"


def main() -> int:
    parser = argparse.ArgumentParser(description="Preflight checks for LiteLLM + Okada integration")
    parser.add_argument("--base-url", default=os.getenv("OKADA_BASE_URL", "http://localhost:8080"))
    parser.add_argument("--route-map", default=os.getenv("OKADA_ROUTE_MAP_PATH"))
    args = parser.parse_args()

    missing = check_env()
    if missing:
        print("Missing required environment variables:", ", ".join(missing))
        return 1

    kernel_ok, kernel_msg = check_kernel(args.base_url)
    print(f"Kernel health: {'OK' if kernel_ok else 'FAIL'} :: {kernel_msg}")
    if not kernel_ok:
        return 1

    route_ok, route_msg = check_route_map(args.route_map)
    print(f"Route map: {'OK' if route_ok else 'FAIL'} :: {route_msg}")
    if not route_ok:
        return 1

    print("Preflight completed successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
