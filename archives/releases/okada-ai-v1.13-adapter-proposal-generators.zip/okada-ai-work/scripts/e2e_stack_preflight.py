from __future__ import annotations

import os
from pathlib import Path

REQUIRED_FILES = [
    Path('ops/integrated/docker-compose.kernel-gateway-ui.yml'),
    Path('ops/integrated/.env.example'),
    Path('examples/litellm/route_map.json'),
    Path('examples/openwebui/okada_governance_pipe.py'),
]

REQUIRED_ENV = [
    'OKADA_KERNEL_URL',
    'LITELLM_MASTER_KEY',
    'OPENAI_API_KEY',
]


def main() -> int:
    errors: list[str] = []
    for path in REQUIRED_FILES:
        if not path.exists():
            errors.append(f'missing file: {path}')
    for name in REQUIRED_ENV:
        if not os.getenv(name):
            errors.append(f'missing env: {name}')

    if errors:
        print('E2E preflight failed:')
        for err in errors:
            print(f'- {err}')
        return 1

    print('E2E preflight passed.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
