from __future__ import annotations

import os
import sys

import httpx


def main() -> int:
    base_url = os.getenv("OKADA_BASE_URL", "http://localhost:8080")
    try:
        response = httpx.get(f"{base_url}/healthz", timeout=5.0)
        response.raise_for_status()
    except Exception as exc:
        print(f"[openwebui_preflight] kernel unreachable: {exc}")
        return 1

    print("[openwebui_preflight] kernel reachable")
    print(f"[openwebui_preflight] base_url={base_url}")
    print("[openwebui_preflight] remember Open WebUI Pipe/Filter code runs as trusted Python")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
