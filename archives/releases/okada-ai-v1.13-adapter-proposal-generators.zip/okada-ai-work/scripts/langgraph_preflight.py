from __future__ import annotations

import json
import os
from pathlib import Path


REQUIRED_ENV = ["OKADA_BASE_URL"]
REQUIRED_FILES = [
    Path("examples/langgraph/okada_agent_graph.py"),
    Path("examples/langgraph/state_schema.py"),
    Path("examples/langgraph/human_review_contract.yaml"),
]


def main() -> int:
    missing_env = [key for key in REQUIRED_ENV if not os.getenv(key)]
    missing_files = [str(path) for path in REQUIRED_FILES if not path.exists()]

    report = {
        "missing_env": missing_env,
        "missing_files": missing_files,
        "ok": not missing_env and not missing_files,
    }
    print(json.dumps(report, indent=2))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
