# LangGraph Example (Gateway Unified)

This graph calls only gateway endpoints:
- `POST /integrations/langgraph/step`
- `POST /integrations/langgraph/human-review`

The gateway owns state translation and mutated-state construction.
