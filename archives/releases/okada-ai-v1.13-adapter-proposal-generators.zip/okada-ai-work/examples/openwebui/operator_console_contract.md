# Operator Console Contract

Open WebUI is the human-facing console for review and audit.

## Metadata fields expected on messages
- `okada_regime`
- `okada_action`
- `okada_type_class`
- `okada_trust_state`
- `okada_audit_trace_id`
- `okada_alternatives`
- `okada_fail_safe_reason`

## Operator actions supported
- continue
- watch
- human_review
- hold
- escalate

## Minimum review checklist
1. Confirm the visible handle is plausible.
2. Confirm the suggested action is proportionate.
3. Confirm the fallback / abstain was not triggered by transient noise.
4. Record notes against the trace id.
