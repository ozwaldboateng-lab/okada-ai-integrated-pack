# Open WebUI Example (Gateway Unified)

Both the Pipe and the Filter call integration-gateway endpoints:
- `POST /integrations/openwebui/pipe`
- `POST /integrations/openwebui/filter`
