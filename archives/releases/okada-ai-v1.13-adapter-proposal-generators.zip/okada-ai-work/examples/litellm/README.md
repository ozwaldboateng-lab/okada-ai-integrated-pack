# LiteLLM Example (Gateway Unified)

This example calls only integration-gateway endpoints:
- `POST /integrations/litellm/pre-route`
- `POST /integrations/litellm/post-audit`

The LiteLLM-side glue no longer builds canonical kernel payloads.
The gateway owns translation, routing policy application, and audit payload construction.
