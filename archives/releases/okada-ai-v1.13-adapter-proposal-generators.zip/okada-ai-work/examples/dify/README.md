# Dify Example (Gateway Unified)

Use Dify HTTP Request nodes against integration-gateway endpoints:
- `POST /integrations/dify/rag/pre-retrieval`
- `POST /integrations/dify/rag/post-retrieval`
- `POST /integrations/dify/fail-safe`

Pattern:
1. HTTP Request node sends `{payload, options}`.
2. Gateway returns `IntegrationResponse`.
3. Code node exports `transformed_payload` as workflow variables.
