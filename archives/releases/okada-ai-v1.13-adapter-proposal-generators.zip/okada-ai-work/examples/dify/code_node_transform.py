def main(okada_response: dict) -> dict:
    scores = okada_response.get("scores", {})
    return {
        "regime": okada_response.get("regime", "mixed"),
        "recommended_action": okada_response.get("recommended_action", "continue"),
        "trust_state": okada_response.get("trust_state", "undefined"),
        "audit_trace_id": okada_response.get("audit_trace_id", ""),
        "context_contamination_score": scores.get("context_contamination_score", 0.0),
        "freshness_gap_score": scores.get("freshness_gap_score", 0.0),
    }
