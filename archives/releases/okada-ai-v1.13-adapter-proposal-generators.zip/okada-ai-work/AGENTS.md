# AGENTS.md

This repository is prepared for autonomous or semi-autonomous coding agents.
Use this file as the default implementation contract unless a more specific task file overrides it.

## 1. Project goal
Build the **Okada Governance Kernel** as an external decision service that improves end-to-end AI system performance under fixed model pools, fixed knowledge sources, and fixed budget constraints.

This repository is **not** a new base model project.
It is a governance layer over existing OSS stacks:
- Dify for app/RAG/workflow
- LiteLLM for model gateway/routing
- LangGraph for agent runtime and human handoff
- Open WebUI for operator console and audit-facing workflows

## 2. Source of truth priority
When files disagree, use this order:
1. `specs/okada-ai-spec/registry/**/*.yaml`
2. `api/*.yaml` and `schemas/*.json`
3. `docs/*.md`
4. implementation code under `apps/okada-kernel-service/`
5. examples under `examples/`

Do not silently invent behavior that conflicts with registry YAML.

## 3. Core design constraints
Every implementation must preserve the Okada decomposition:
- `H_dom`: dominant route
- `H_hist`: retained history / load
- `H_comp`: competitor pressure
- `V_first`: first visible handle
- `regime`: `clean | mixed | contaminated`
- optional `type_class`: `I | II | III`

Never reduce the system to a single opaque score without keeping the decomposition visible in audit output.

## 4. What success means
The target claim is not “the model is smarter.”
The target claim is:

> Under the same model pool, same knowledge sources, and same budget constraints,
> the Okada-governed system achieves better end-to-end performance than simpler baselines.

Prefer implementations that improve:
- task success
- groundedness
- stale/contaminated context handling
- catastrophic failure containment
- cost per successful task
- latency under fixed quality

## 5. Development order
Unless a task explicitly overrides this, work in this order:
1. Kernel service correctness
2. API/schema alignment
3. Audit completeness
4. LiteLLM routing integration
5. Dify RAG integration
6. LangGraph agent governance
7. Open WebUI operator/audit integration
8. E2E benchmark harness and baseline comparisons

## 6. Editing rules
- Make the smallest coherent change that completes the task.
- Keep public interfaces stable unless the task is explicitly about redesigning them.
- Update docs and fixtures when behavior changes.
- Add or update tests for every meaningful behavior change.
- Prefer explicit dataclasses/models and typed payload builders over ad hoc dict mutation.
- Keep gateway/client code thin; put decision logic in the kernel service.

## 7. Safety / non-goals
Do not:
- claim universal superiority
- hard-code production secrets
- embed API keys in examples
- silently widen scope from governance to general autonomy or alignment claims
- replace domain detectors with vague Okada-only heuristics

## 8. Required checks before handoff
Run as many as are relevant:
```bash
pytest apps/okada-kernel-service/tests -q
python scripts/validate_specs.py
python scripts/e2e_compare.py --pretty
```
If a task changes only docs/prompts and not executable code, say so explicitly.

## 9. Task slicing guidance
Good task sizes:
- “Implement missing routing decision branch for `mixed` regime in LiteLLM gateway client”
- “Add RAG stale-source fixture cases and make abstain decision auditable”
- “Wire LangGraph interrupt payloads through `/integrations/langgraph/step`”

Bad task sizes:
- “Finish the whole system”
- “Make it production-ready”
- “Optimize all adapters”

## 10. Handoff format
When finishing a task, report:
1. what changed
2. which files are source-of-truth affected
3. what tests were run
4. what remains open
