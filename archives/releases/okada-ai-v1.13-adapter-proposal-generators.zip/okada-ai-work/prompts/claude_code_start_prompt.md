# Claude Code start prompt

Use `CLAUDE.md` as the repository-specific operating guide.
Also read `AGENTS.md` because it contains the source-of-truth order and task-sizing rules.

Focus on implementation tasks that preserve:
- specification-first development
- explicit auditability
- Okada decomposition visibility
- thin OSS glue / centralized governance logic

Before coding, identify the exact source-of-truth YAML files for the feature.
After coding, report:
- changed files
- design impact
- tests run
- follow-up tasks
