# Dual-agent bootstrap prompt

This repository is intentionally prepared for both Codex-style and Claude Code-style development.

## Start sequence
1. Read `README.md`
2. Read `AGENTS.md`
3. Read `CLAUDE.md`
4. Read the relevant registry YAML under `specs/okada-ai-spec/registry/`
5. Inspect current tests under `apps/okada-kernel-service/tests`

## Your job
Implement the next small, testable improvement without breaking the source-of-truth contracts.

## Repository rules
- Do not remove Okada decomposition fields from outputs.
- Keep kernel/gateway logic centralized.
- Keep examples as examples; do not move core behavior into them.
- Prefer additive changes over destructive rewrites.

## Recommended first tasks
- strengthen gateway/client tests
- enrich fixtures for mixed/contaminated cases
- tighten schema validation
- improve one adapter at a time
