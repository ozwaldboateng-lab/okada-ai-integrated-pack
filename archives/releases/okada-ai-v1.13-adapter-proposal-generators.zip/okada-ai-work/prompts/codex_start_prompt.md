# Codex start prompt

Work in this repository as an implementation agent.
Read `AGENTS.md` first, then `README.md`, then the relevant adapter YAML under `specs/okada-ai-spec/registry/`.

Your goal is to continue implementation without changing the project mission:
- external Okada governance kernel
- measurable end-to-end performance improvements under fixed conditions
- thin glue around Dify / LiteLLM / LangGraph / Open WebUI

Start by inspecting the current tests and gateway contracts.
Do not rewrite unrelated parts of the repository.
When done, provide:
- concise change summary
- changed files
- tests run
- open issues
