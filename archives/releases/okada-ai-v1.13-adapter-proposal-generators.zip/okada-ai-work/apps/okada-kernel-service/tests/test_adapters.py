from __future__ import annotations

from app.adapters.registry import registry
from app.core.policy import resolve_policy
from app.models.contracts import DiagnoseRequest


def make_request(adapter_type: str, spec_id: str) -> DiagnoseRequest:
    return DiagnoseRequest(
        spec_id=spec_id,
        adapter_type=adapter_type,  # type: ignore[arg-type]
        observables={
            "fallback_rate": 0.2,
            "override_rate": 0.1,
            "latency_instability": 0.1,
            "feature_drift_score": 0.3,
            "planner_executor_mismatch": 0.4,
            "tool_disagreement": 0.2,
            "grounding_confidence": 0.5,
            "chunk_conflict_rate": 0.4,
            "complexity_proxy": 0.7,
            "historical_route_success": 0.8,
            "budget_remaining": 0.4,
        },
        context={},
        history_state={},
        resource_state={},
    )


def test_all_stub_adapters_return_decomposition() -> None:
    cases = [
        ("monitoring", "OKD-AI-001"),
        ("mlops", "OKD-AI-002"),
        ("agent", "OKD-AI-003"),
        ("rag", "OKD-AI-004"),
        ("routing", "OKD-AI-005"),
    ]
    policy = resolve_policy(None)
    for adapter_type, spec_id in cases:
        decision = registry.get(adapter_type).diagnose(make_request(adapter_type, spec_id), policy)
        assert "H_dom" in decision.derived_features
        assert "H_hist" in decision.derived_features
        assert "H_comp" in decision.derived_features
        assert decision.regime in {"clean", "mixed", "contaminated"}
