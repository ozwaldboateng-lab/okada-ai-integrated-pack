from __future__ import annotations

from app.audit.store import audit_store


def test_audit_records_exist_after_api_calls() -> None:
    records = audit_store.list_records()
    assert isinstance(records, list)
