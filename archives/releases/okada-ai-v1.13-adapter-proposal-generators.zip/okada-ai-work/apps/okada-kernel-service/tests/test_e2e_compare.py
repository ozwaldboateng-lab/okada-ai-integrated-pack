from __future__ import annotations

import json
from pathlib import Path

from app.benchmark.e2e_compare import load_cases, run_case, summarize


def test_e2e_cases_exist():
    cases = load_cases()
    assert cases
    assert any(case['spec_id'] == 'OKD-AI-005' for case in cases)


def test_e2e_summary_has_positive_gain_for_some_cases():
    results = [run_case(case) for case in load_cases()]
    summary = summarize(results)
    assert summary['total_cases'] >= 4
    assert summary['wins'] >= 2
    assert summary['total_gain'] > 0
