from __future__ import annotations

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def _payload(adapter_type: str, spec_id: str) -> dict:
    return {
        "spec_id": spec_id,
        "adapter_type": adapter_type,
        "observables": {
            "grounding_confidence": 0.3,
            "chunk_conflict_rate": 0.6,
            "index_age": 0.7,
            "source_freshness": 0.2,
            "budget_remaining": 0.5,
            "complexity_proxy": 0.7,
        },
        "context": {},
        "history_state": {},
        "resource_state": {},
    }


def test_healthz() -> None:
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_diagnose_rag() -> None:
    response = client.post("/okada/diagnose", json=_payload("rag", "OKD-AI-004"))
    assert response.status_code == 200
    body = response.json()
    assert body["spec_id"] == "OKD-AI-004"
    assert body["regime"] in {"clean", "mixed", "contaminated"}
    assert body["audit_persisted"] is True


def test_route_routing() -> None:
    payload = _payload("routing", "OKD-AI-005")
    response = client.post("/okada/route", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert "recommended_action" in body
    assert body["audit_trace_id"]
