from __future__ import annotations

from app.adapters.base import AdapterDecision, BaseAdapter
from app.core.scoring import bounded, flatten_numeric, mean


class DriftAdapter(BaseAdapter):
    name = "mlops"

    def diagnose(self, request, policy):
        numeric = flatten_numeric(request.observables)
        signal = mean(list(numeric.values()))
        risk_bonus = 0.0
        if request.context.get("high_risk_action_flag") or request.context.get("question_time_sensitivity") == "high":
            risk_bonus = policy.thresholds.get("high_risk_bonus", 0.15)

        h_dom = bounded(1.0 - bounded(numeric.get('feature_drift_score', 0.0) * 0.4 + numeric.get('uncertainty_drift', 0.0) * 0.3 + numeric.get('performance_decay_proxy', 0.0) * 0.3))
        h_hist = bounded(bounded(numeric.get('calibration_lag', 0.0) * 0.7 + numeric.get('label_delay', 0.0) * 0.3))
        h_comp = bounded(bounded(numeric.get('challenger_disagreement', 0.0) * 0.5 + numeric.get('label_drift_proxy', 0.0) * 0.5))
        r_diag = (policy.weights["W_hist"] * abs(h_hist) + policy.weights["W_comp"] * abs(h_comp)) / (policy.weights["W_dom"] * abs(h_dom) + 1e-6)

        if h_dom >= 0.65 and r_diag < policy.thresholds["T_clean"]:
            regime = "clean"
        elif h_dom >= 0.35 and r_diag < policy.thresholds["T_contam"]:
            regime = "mixed"
        else:
            regime = "contaminated"

        type_class = "II" if numeric.get("challenger_disagreement",0.0) > 0 else "I"
        trust_state = "safe" if regime == "clean" else "caution" if regime == "mixed" else "unsafe"
        handles = []
        for key, value in sorted(numeric.items(), key=lambda kv: kv[1], reverse=True)[:3]:
            if value > 0:
                handles.append(key.replace(".", "_"))
        if not handles:
            handles = ["no_signal"]

        recommended_action = "keep" if regime == "clean" else "shadow_deploy" if regime == "mixed" else ("rollback" if numeric.get("rollback_candidate_available",0.0) > 0.5 else "retrain")
        alternatives = ["watch", "retrain"] if regime == "mixed" else ["keep"] if regime == "clean" else ["retrain", "rollback"]

        return AdapterDecision(
            normalized_inputs=numeric,
            derived_features={
                "H_dom": round(h_dom, 4),
                "H_hist": round(h_hist, 4),
                "H_comp": round(h_comp, 4),
                "R_diag": round(r_diag, 4),
            },
            regime=regime,
            type_class=type_class,
            trust_state=trust_state,
            first_visible_handle=handles,
            recommended_action=recommended_action,
            alternatives=alternatives,
        )
