from __future__ import annotations

from typing import Any


def _to_float(value: Any) -> float:
    if isinstance(value, bool):
        return 1.0 if value else 0.0
    if isinstance(value, (int, float)):
        return float(value)
    return 0.0


def flatten_numeric(data: dict[str, Any]) -> dict[str, float]:
    flat: dict[str, float] = {}
    for key, value in data.items():
        if isinstance(value, dict):
            nested = flatten_numeric(value)
            for nkey, nvalue in nested.items():
                flat[f"{key}.{nkey}"] = nvalue
        elif isinstance(value, list):
            if value and all(isinstance(v, (int, float, bool)) for v in value):
                flat[key] = sum(_to_float(v) for v in value) / len(value)
        else:
            flat[key] = _to_float(value)
    return flat


def bounded(value: float, *, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0
