from __future__ import annotations

from app.auto_calibration.store import adopted_policy_store
from app.config.settings import settings
from app.models.contracts import PolicyProfile


DEFAULT_THRESHOLDS = {
    "T_clean": 0.45,
    "T_contam": 0.95,
    "high_risk_bonus": 0.15,
}

DEFAULT_WEIGHTS = {
    "W_dom": 1.0,
    "W_hist": 1.0,
    "W_comp": 1.0,
}


def resolve_policy(profile: PolicyProfile | None) -> PolicyProfile:
    profile_name = profile.profile_name if profile is not None else settings.default_policy
    thresholds = DEFAULT_THRESHOLDS.copy()
    weights = DEFAULT_WEIGHTS.copy()
    preferred_actions: dict[str, list[str]] = {}

    adopted = adopted_policy_store.get(profile_name)
    if adopted:
        thresholds.update(dict(adopted.get("thresholds") or {}))
        weights.update(dict(adopted.get("weights") or {}))
        preferred_actions.update(dict(adopted.get("preferred_actions") or {}))

    if profile is not None:
        thresholds.update(profile.thresholds)
        weights.update(profile.weights)
        preferred_actions.update(profile.preferred_actions)

    return PolicyProfile(
        profile_name=profile_name,
        deterministic_mode=profile.deterministic_mode if profile is not None else True,
        thresholds=thresholds,
        weights=weights,
        preferred_actions=preferred_actions,
    )
