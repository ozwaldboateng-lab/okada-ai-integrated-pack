from __future__ import annotations

from fastapi import APIRouter, HTTPException

from app.auto_calibration.champion_challenger import champion_challenger_service
from app.auto_calibration.metric_aggregators import adapter_metric_aggregator_service
from app.auto_calibration.scheduler import scheduler_service
from app.auto_calibration.service import auto_calibration_service
from app.auto_calibration.window_aggregator import calibration_window_service
from app.auto_calibration.store import auto_calibration_audit_store
from app.models.auto_calibration import (
    AutoCalibrationAdoptRequest,
    AutoCalibrationAdoptResponse,
    AutoCalibrationAuditRecord,
    AutoCalibrationProposalResponse,
    AutoCalibrationRequest,
    AutoCalibrationValidationRequest,
    AutoCalibrationValidationResponse,
    AdapterMetricSummaryRequest,
    AdapterMetricSummaryResponse,
    CalibrationWindowRequest,
    CalibrationWindowResponse,
    CandidatePrepareRequest,
    CandidatePrepareResponse,
    CandidatePromoteRequest,
    CandidatePromoteResponse,
    ChampionChallengerCandidate,
    ProfileCatalogEntry,
    SchedulerPlan,
    SchedulerPlanStatus,
    SchedulerRunRequest,
    SchedulerRunResult,
    ShadowEvaluateRequest,
    ShadowEvaluateResponse,
)

router = APIRouter(prefix="/okada/auto-calibration", tags=["auto-calibration"])


@router.get("/profiles", response_model=list[ProfileCatalogEntry])
def list_profiles() -> list[ProfileCatalogEntry]:
    return auto_calibration_service.list_profiles()


@router.post("/propose", response_model=AutoCalibrationProposalResponse)
def propose(request: AutoCalibrationRequest) -> AutoCalibrationProposalResponse:
    try:
        return auto_calibration_service.propose(request)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/validate", response_model=AutoCalibrationValidationResponse)
def validate(request: AutoCalibrationValidationRequest) -> AutoCalibrationValidationResponse:
    try:
        return auto_calibration_service.validate(request)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/adopt", response_model=AutoCalibrationAdoptResponse)
def adopt(request: AutoCalibrationAdoptRequest) -> AutoCalibrationAdoptResponse:
    try:
        return auto_calibration_service.adopt(request)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/history", response_model=list[AutoCalibrationAuditRecord])
def history() -> list[AutoCalibrationAuditRecord]:
    return auto_calibration_audit_store.list_records()


@router.post("/windows/resolve", response_model=CalibrationWindowResponse)
def resolve_calibration_window(request: CalibrationWindowRequest) -> CalibrationWindowResponse:
    try:
        return calibration_window_service.resolve(request)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/metrics/summarize", response_model=AdapterMetricSummaryResponse)
def summarize_adapter_metrics(request: AdapterMetricSummaryRequest) -> AdapterMetricSummaryResponse:
    try:
        return adapter_metric_aggregator_service.summarize(request)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/scheduler/plans", response_model=list[SchedulerPlan])
def list_scheduler_plans() -> list[SchedulerPlan]:
    return scheduler_service.list_plans()


@router.get("/scheduler/status", response_model=list[SchedulerPlanStatus])
def scheduler_status() -> list[SchedulerPlanStatus]:
    return scheduler_service.plan_status()


@router.post("/scheduler/run-plan", response_model=SchedulerRunResult)
def run_scheduler_plan(request: SchedulerRunRequest) -> SchedulerRunResult:
    try:
        return scheduler_service.run_plan(request)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/scheduler/run-due", response_model=list[SchedulerRunResult])
def run_due_scheduler(request: SchedulerRunRequest) -> list[SchedulerRunResult]:
    try:
        return scheduler_service.run_due(now=request.now, force=request.force)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/champion-challenger/candidates", response_model=list[ChampionChallengerCandidate])
def list_candidates(profile_name: str | None = None) -> list[ChampionChallengerCandidate]:
    return champion_challenger_service.list_candidates(profile_name=profile_name)


@router.post("/champion-challenger/prepare", response_model=CandidatePrepareResponse)
def prepare_candidate(request: CandidatePrepareRequest) -> CandidatePrepareResponse:
    try:
        return champion_challenger_service.prepare_candidate(request)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/champion-challenger/evaluate", response_model=ShadowEvaluateResponse)
def evaluate_candidate(request: ShadowEvaluateRequest) -> ShadowEvaluateResponse:
    try:
        return champion_challenger_service.evaluate_shadow(request)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/champion-challenger/promote", response_model=CandidatePromoteResponse)
def promote_candidate(request: CandidatePromoteRequest) -> CandidatePromoteResponse:
    try:
        return champion_challenger_service.promote(request)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
