from __future__ import annotations

import json
from pathlib import Path

from app.config.settings import settings
from app.models.contracts import AuditRecord


class AuditStore:
    def __init__(self, audit_dir: Path | None = None) -> None:
        self.audit_dir = audit_dir or settings.audit_dir
        self.audit_dir.mkdir(parents=True, exist_ok=True)
        self.audit_file = self.audit_dir / "audit_records.jsonl"

    def write(self, record: AuditRecord) -> AuditRecord:
        with self.audit_file.open("a", encoding="utf-8") as fh:
            fh.write(record.model_dump_json())
            fh.write("\n")
        return record

    def list_records(self) -> list[AuditRecord]:
        if not self.audit_file.exists():
            return []
        records: list[AuditRecord] = []
        for line in self.audit_file.read_text(encoding="utf-8").splitlines():
            if line.strip():
                records.append(AuditRecord.model_validate_json(line))
        return records


audit_store = AuditStore()
