from __future__ import annotations

from fastapi import FastAPI

from app.api.integration_routes import router as integration_router
from app.api.routes import router

app = FastAPI(title="Okada Governance Kernel", version="1.1.0")
app.include_router(router)
app.include_router(integration_router)
