from __future__ import annotations

import os
from typing import Any

import httpx
from pydantic import BaseModel, Field

from app.integrations.openwebui_runtime import build_openwebui_headers, build_pipe_payload, transform_pipe_decision


class Pipe:
    class Valves(BaseModel):
        NAME_PREFIX: str = Field(default="OKADA/")
        CHEAP_MODEL_ID: str = Field(default="gpt-4o-mini")
        STRONG_MODEL_ID: str = Field(default="gpt-4.1")
        OKADA_BASE_URL: str = Field(default=os.getenv("OKADA_BASE_URL", "http://localhost:8080"))
        OKADA_SHARED_TOKEN: str = Field(default=os.getenv("OKADA_SHARED_TOKEN", ""))

    def __init__(self):
        self.valves = self.Valves()

    def pipes(self):
        return [
            {"id": "okada.router", "name": f"{self.valves.NAME_PREFIX}router"},
        ]

    async def pipe(self, body: dict, __user__: dict | None = None) -> Any:
        payload = build_pipe_payload(body, user=__user__)

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(
                f"{self.valves.OKADA_BASE_URL}/okada/route",
                json=payload,
                headers=build_openwebui_headers(self.valves.OKADA_SHARED_TOKEN),
            )
            response.raise_for_status()
            decision = response.json()

        transformed = transform_pipe_decision(
            body,
            decision,
            cheap_model_id=self.valves.CHEAP_MODEL_ID,
            strong_model_id=self.valves.STRONG_MODEL_ID,
        )

        return {
            "selected_model": transformed.get("selected_model", self.valves.CHEAP_MODEL_ID),
            "okada_regime": transformed.get("metadata", {}).get("okada_regime"),
            "okada_action": transformed.get("metadata", {}).get("okada_action"),
            "okada_audit_trace_id": transformed.get("metadata", {}).get("okada_audit_trace_id"),
            "okada_type_class": transformed.get("metadata", {}).get("okada_type_class"),
            "okada_alternatives": transformed.get("metadata", {}).get("okada_alternatives", []),
        }
