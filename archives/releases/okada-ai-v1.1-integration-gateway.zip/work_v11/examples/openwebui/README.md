# Open WebUI Integration Example

Open WebUI is used here as the operator-facing surface for:
- route-aware model access via a Pipe
- governance metadata injection via a Filter
- manual review / audit inspection through message metadata

This folder contains:
- `okada_governance_pipe.py`: route-aware custom model pipe
- `okada_audit_filter.py`: inlet/outlet filter for governance metadata and audit
- `operator_console_contract.md`: operator review fields and expectations
- `pipes_manifest.yaml`: suggested registration and naming
- `README.md`: setup guidance

## Recommended usage split
- Use the **Pipe** for OKD-AI-005 routing decisions.
- Use the **Filter** for OKD-AI-001 trust-window monitoring and audit metadata.
- Keep Open WebUI as the human-facing console, not the core execution engine.
