from __future__ import annotations

import os

import httpx
from pydantic import BaseModel, Field

from app.integrations.openwebui_runtime import (
    build_filter_audit_payload,
    build_filter_payload,
    build_openwebui_headers,
    fail_safe_filter_variables,
    transform_filter_decision,
)


class Filter:
    class Valves(BaseModel):
        OKADA_BASE_URL: str = Field(default=os.getenv("OKADA_BASE_URL", "http://localhost:8080"))
        OKADA_SHARED_TOKEN: str = Field(default=os.getenv("OKADA_SHARED_TOKEN", ""))
        BLOCK_ON_CONTAMINATED: bool = Field(default=False)

    def __init__(self):
        self.valves = self.Valves()

    async def inlet(self, body: dict, __user__: dict | None = None):
        payload = build_filter_payload(body, user=__user__)
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(
                    f"{self.valves.OKADA_BASE_URL}/okada/diagnose",
                    json=payload,
                    headers=build_openwebui_headers(self.valves.OKADA_SHARED_TOKEN),
                )
                response.raise_for_status()
                decision = response.json()
            transformed = transform_filter_decision(body, decision)
            body.update(transformed)
        except Exception:
            body.setdefault("metadata", {}).update(fail_safe_filter_variables())

        if self.valves.BLOCK_ON_CONTAMINATED and body.get("metadata", {}).get("okada_regime") == "contaminated":
            raise RuntimeError("Blocked by Okada governance filter")
        return body

    async def outlet(self, body: dict, __user__: dict | None = None):
        body.setdefault("metadata", {})
        body["metadata"]["okada_audit_payload"] = build_filter_audit_payload(body)
        return body
