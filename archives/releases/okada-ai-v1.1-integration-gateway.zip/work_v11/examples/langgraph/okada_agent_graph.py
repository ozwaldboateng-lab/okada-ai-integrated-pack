from __future__ import annotations

import os
from typing import Any

import httpx
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt

from state_schema import AgentState


OKADA_BASE_URL = os.getenv("OKADA_BASE_URL", "http://localhost:8080")
OKADA_SHARED_TOKEN = os.getenv("OKADA_SHARED_TOKEN")


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if OKADA_SHARED_TOKEN:
        headers["Authorization"] = f"Bearer {OKADA_SHARED_TOKEN}"
    return headers


def _call_okada(payload: dict[str, Any]) -> dict[str, Any]:
    response = httpx.post(
        f"{OKADA_BASE_URL}/okada/intervene",
        json=payload,
        headers=_headers(),
        timeout=10.0,
    )
    response.raise_for_status()
    return response.json()


def plan_node(state: AgentState) -> AgentState:
    state["current_step"] = "plan"
    state["plan"] = f"Search internal knowledge and answer: {state['user_request']}"
    state["tool_name"] = "search_docs"
    state["tool_input"] = state["user_request"]
    return state


def _payload(state: AgentState, stage: str) -> dict[str, Any]:
    return {
        "spec_id": "OKD-AI-003",
        "adapter_type": "agent",
        "observables": {
            "planner_executor_mismatch": state.get("planner_executor_mismatch", 0.0),
            "tool_disagreement": state.get("tool_disagreement", 0.0),
            "retry_count": state.get("retry_count", 0),
            "unresolved_subgoal_count": state.get("unresolved_subgoal_count", 0),
            "route_split_frequency": state.get("route_split_frequency", 0.0),
            "retrieval_contradiction_rate": state.get("retrieval_contradiction_rate", 0.0),
            "context_age_penalty": state.get("context_age_penalty", 0.0),
        },
        "context": {
            "stage": stage,
            "user_request": state.get("user_request", ""),
            "plan": state.get("plan", ""),
            "tool_name": state.get("tool_name", ""),
            "high_risk_action_flag": state.get("high_risk_action_flag", False),
        },
        "history_state": {
            "prior_branch_failures": state.get("prior_branch_failures", 0),
            "stale_context_rounds": state.get("stale_context_rounds", 0),
        },
        "resource_state": {
            "remaining_step_budget": state.get("remaining_step_budget", 0),
            "human_confirmation_available": state.get("human_confirmation_available", False),
            "time_budget_seconds": state.get("time_budget_seconds", 0.0),
        },
        "policy_profile": {"profile_name": "default", "deterministic_mode": True},
    }


def governance_node(stage: str):
    def _node(state: AgentState) -> AgentState:
        state["current_step"] = stage
        decision = _call_okada(_payload(state, stage))
        state["governance_action"] = decision["recommended_action"]
        state["governance_regime"] = decision["regime"]
        state["audit_trace_id"] = decision["audit_trace_id"]
        state["route_integrity_score"] = float(decision.get("scores", {}).get("route_integrity_score", 0.0))
        state["escalation_pressure_score"] = float(decision.get("scores", {}).get("escalation_pressure_score", 0.0))

        if decision["recommended_action"] in {"human_handoff", "abort", "intermediate_confirmation"}:
            human_decision = interrupt(
                {
                    "message": "Okada governance requested review",
                    "recommended_action": decision["recommended_action"],
                    "regime": decision["regime"],
                    "audit_trace_id": decision["audit_trace_id"],
                    "plan": state.get("plan", ""),
                    "tool_name": state.get("tool_name", ""),
                }
            )
            state["human_review_action"] = human_decision.get("action", decision["recommended_action"])
            state["human_review_notes"] = human_decision.get("notes", "")
            state["governance_action"] = state["human_review_action"]
        return state

    return _node


def tool_node(state: AgentState) -> AgentState:
    state["current_step"] = "tool"
    state["tool_output"] = f"tool({state['tool_name']}) => result for {state['tool_input']}"
    return state


def replan_node(state: AgentState) -> AgentState:
    state["current_step"] = "replan"
    state["plan"] = f"Replanned: summarize first, then answer {state['user_request']}"
    state["tool_name"] = "summarize_context"
    state["tool_input"] = state["user_request"]
    return state


def final_node(state: AgentState) -> AgentState:
    state["current_step"] = "final"
    if state.get("governance_action") == "abort":
        state["final_answer"] = "Aborted due to Okada governance."
    else:
        state["final_answer"] = f"{state.get('plan', '')} | {state.get('tool_output', '')}"
    return state


def route_after_governance(state: AgentState) -> str:
    action = state.get("governance_action", "continue")
    if action == "abort":
        return "final"
    if action == "replan":
        return "replan"
    return "tool"


def route_after_post_tool(state: AgentState) -> str:
    action = state.get("governance_action", "continue")
    if action == "abort":
        return "final"
    if action == "replan":
        return "replan"
    return "final"


def build_graph():
    graph = StateGraph(AgentState)
    graph.add_node("plan", plan_node)
    graph.add_node("governance_before_tool", governance_node("before_tool"))
    graph.add_node("tool", tool_node)
    graph.add_node("governance_after_tool", governance_node("after_tool"))
    graph.add_node("replan", replan_node)
    graph.add_node("final", final_node)

    graph.add_edge(START, "plan")
    graph.add_edge("plan", "governance_before_tool")
    graph.add_conditional_edges(
        "governance_before_tool",
        route_after_governance,
        {"tool": "tool", "replan": "replan", "final": "final"},
    )
    graph.add_edge("replan", "tool")
    graph.add_edge("tool", "governance_after_tool")
    graph.add_conditional_edges(
        "governance_after_tool",
        route_after_post_tool,
        {"replan": "replan", "final": "final"},
    )
    graph.add_edge("final", END)
    return graph.compile(checkpointer=MemorySaver())
