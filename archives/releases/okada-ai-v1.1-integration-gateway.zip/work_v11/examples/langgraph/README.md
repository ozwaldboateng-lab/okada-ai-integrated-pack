# LangGraph Integration Example (Detailed)

This folder contains the detailed LangGraph-side integration pattern for **OKD-AI-003 Agentic AI Route Contamination and Escalation Governance**.

## Files
- `state_schema.py`: richer state contract for agent governance
- `okada_agent_graph.py`: graph with conditional routing, interrupt, replan, and finalization
- `human_review_contract.yaml`: expected payload between the graph and human reviewer
- `checkpoint_config.example.json`: thread/checkpoint configuration example
- `conditional_edge_map.md`: route mapping from Okada actions to graph edges

## Design intent
The graph is structured around **two governance checkpoints**:
1. before tool execution
2. after tool execution

At each checkpoint, the graph can:
- continue
- replan
- interrupt for human review
- abort

## Notes
- `interrupt()` requires a checkpointer and a `thread_id` in the runtime config.
- The example uses `MemorySaver()` for local experimentation only.
- Production persistence should be replaced with a durable checkpointer.
