# Okada AI v1.8 Auto-Calibration Manager Pack

This package adds an Auto-Calibration Manager design layer to the Okada AI platform.
It is intended to be merged into the main specification / implementation repository.

Included:
- overview design documents
- source-of-truth registry YAML
- calibration policy profiles
- OpenAPI draft for calibration endpoints
- JSON Schema drafts
- sample fixtures
- codegen handoff prompts
