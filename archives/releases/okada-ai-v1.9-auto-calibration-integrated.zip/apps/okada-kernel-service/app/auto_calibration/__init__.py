"""Auto-calibration package for the Okada Kernel service."""
