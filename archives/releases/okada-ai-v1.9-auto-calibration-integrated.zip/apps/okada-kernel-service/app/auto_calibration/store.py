from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from app.config.settings import settings
from app.models.auto_calibration import AutoCalibrationAuditRecord
from app.models.contracts import PolicyProfile


class AdoptedPolicyStore:
    def __init__(self, path: Path | None = None) -> None:
        self.path = path or settings.adopted_policy_file
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("{}\n", encoding="utf-8")

    def load_all(self) -> dict[str, dict[str, Any]]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def get(self, profile_name: str) -> dict[str, Any] | None:
        return self.load_all().get(profile_name)

    def upsert(self, profile_name: str, policy: PolicyProfile, *, metadata: dict[str, Any] | None = None) -> dict[str, Any]:
        current = self.load_all()
        entry = {
            "profile_name": profile_name,
            "thresholds": policy.thresholds,
            "weights": policy.weights,
            "preferred_actions": policy.preferred_actions,
        }
        if metadata:
            entry["metadata"] = metadata
        current[profile_name] = entry
        self.path.write_text(json.dumps(current, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return entry


class AutoCalibrationAuditStore:
    def __init__(self, path: Path | None = None) -> None:
        self.path = path or settings.auto_calibration_history_file
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, record: AutoCalibrationAuditRecord) -> AutoCalibrationAuditRecord:
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(record.model_dump_json())
            fh.write("\n")
        return record

    def list_records(self) -> list[AutoCalibrationAuditRecord]:
        if not self.path.exists():
            return []
        records: list[AutoCalibrationAuditRecord] = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                records.append(AutoCalibrationAuditRecord.model_validate_json(line))
        return records


adopted_policy_store = AdoptedPolicyStore()
auto_calibration_audit_store = AutoCalibrationAuditStore()
