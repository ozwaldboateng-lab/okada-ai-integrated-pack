from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal

from pydantic import BaseModel, Field

from app.models.contracts import PolicyProfile, Regime

CalibrationMode = Literal[
    "disabled",
    "suggest_only",
    "approval_gated",
    "shadow_challenger",
    "guarded_auto_adopt",
]

CalibrationScope = Literal["thresholds", "weights", "thresholds_and_weights"]
InvocationType = Literal["diagnose", "route", "intervene"]


class CalibrationOutcome(BaseModel):
    success: bool | None = None
    utility: float | None = None
    quality: float | None = None
    cost: float | None = None
    latency_ms: float | None = None
    catastrophic_failure: bool = False
    manual_override: bool = False
    grounded_accuracy: float | None = None
    stale_answer: bool = False


class WindowRecord(BaseModel):
    timestamp: datetime | None = None
    spec_id: str
    adapter_type: str
    invocation: InvocationType = "diagnose"
    observables: dict[str, Any] = Field(default_factory=dict)
    context: dict[str, Any] = Field(default_factory=dict)
    history_state: dict[str, Any] = Field(default_factory=dict)
    resource_state: dict[str, Any] = Field(default_factory=dict)
    expected_regime: Regime | None = None
    expected_action: str | None = None
    outcome: CalibrationOutcome | None = None
    source: str = "inline"


class AutoCalibrationRequest(BaseModel):
    profile_name: str
    spec_id: str
    adapter_type: str
    calibration_scope: CalibrationScope = "thresholds_and_weights"
    window_records: list[WindowRecord] = Field(default_factory=list)
    use_recent_audits: bool = False
    audit_limit: int = 500
    constraints: dict[str, float] = Field(default_factory=dict)
    dry_run: bool = True


class ProfileCatalogEntry(BaseModel):
    profile_name: str
    adapter_type: str
    mode: CalibrationMode
    mutable_thresholds: list[str] = Field(default_factory=list)
    mutable_weights: list[str] = Field(default_factory=list)
    adoption_gate: dict[str, Any] = Field(default_factory=dict)
    rollback_gate: dict[str, Any] = Field(default_factory=dict)
    window: dict[str, Any] = Field(default_factory=dict)


class CalibrationSummary(BaseModel):
    window_size: int
    rdiag_p40: float
    rdiag_p80: float
    mean_h_dom: float
    mean_h_hist: float
    mean_h_comp: float


class AutoCalibrationProposalResponse(BaseModel):
    profile_name: str
    spec_id: str
    adapter_type: str
    mode: CalibrationMode
    proposed_policy: PolicyProfile
    summary: CalibrationSummary
    mutable_parameters: dict[str, list[str]] = Field(default_factory=dict)
    safety_notes: list[str] = Field(default_factory=list)
    source_window: str = "inline"


class ValidationMetrics(BaseModel):
    utility: float
    success_rate: float
    quality: float
    grounded_accuracy: float
    mean_cost: float
    p95_latency_ms: float
    abstain_rate: float
    handoff_rate: float
    catastrophic_rate: float


class ValidationDelta(BaseModel):
    utility_gain: float
    success_drop: float
    quality_gain: float
    grounded_accuracy_gain: float
    cost_increase: float
    latency_increase: float
    abstain_increase: float
    handoff_increase: float
    catastrophic_increase: float


class AutoCalibrationValidationRequest(BaseModel):
    profile_name: str
    spec_id: str
    adapter_type: str
    proposed_policy: PolicyProfile
    window_records: list[WindowRecord] = Field(default_factory=list)
    use_recent_audits: bool = False
    audit_limit: int = 500


class AutoCalibrationValidationResponse(BaseModel):
    profile_name: str
    spec_id: str
    adapter_type: str
    mode: CalibrationMode
    baseline_metrics: ValidationMetrics
    candidate_metrics: ValidationMetrics
    delta: ValidationDelta
    adoption_recommended: bool
    blocking_reasons: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class AutoCalibrationAdoptRequest(BaseModel):
    profile_name: str
    spec_id: str
    adapter_type: str
    proposed_policy: PolicyProfile
    validation_report: AutoCalibrationValidationResponse
    operator_id: str = "system"
    force: bool = False


class AutoCalibrationAdoptResponse(BaseModel):
    profile_name: str
    spec_id: str
    adapter_type: str
    adopted: bool
    revision_id: str | None = None
    stored_path: str | None = None
    message: str


class AutoCalibrationAuditRecord(BaseModel):
    revision_id: str
    timestamp: datetime
    profile_name: str
    spec_id: str
    adapter_type: str
    mode: CalibrationMode
    proposed_policy: PolicyProfile
    validation_report: AutoCalibrationValidationResponse
    operator_id: str

    @classmethod
    def now(
        cls,
        *,
        revision_id: str,
        profile_name: str,
        spec_id: str,
        adapter_type: str,
        mode: CalibrationMode,
        proposed_policy: PolicyProfile,
        validation_report: AutoCalibrationValidationResponse,
        operator_id: str,
    ) -> "AutoCalibrationAuditRecord":
        return cls(
            revision_id=revision_id,
            timestamp=datetime.now(timezone.utc),
            profile_name=profile_name,
            spec_id=spec_id,
            adapter_type=adapter_type,
            mode=mode,
            proposed_policy=proposed_policy,
            validation_report=validation_report,
            operator_id=operator_id,
        )
