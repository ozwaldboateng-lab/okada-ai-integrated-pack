from __future__ import annotations

from fastapi import APIRouter, HTTPException

from app.auto_calibration.service import auto_calibration_service
from app.auto_calibration.store import auto_calibration_audit_store
from app.models.auto_calibration import (
    AutoCalibrationAdoptRequest,
    AutoCalibrationAdoptResponse,
    AutoCalibrationAuditRecord,
    AutoCalibrationProposalResponse,
    AutoCalibrationRequest,
    AutoCalibrationValidationRequest,
    AutoCalibrationValidationResponse,
    ProfileCatalogEntry,
)

router = APIRouter(prefix="/okada/auto-calibration", tags=["auto-calibration"])


@router.get("/profiles", response_model=list[ProfileCatalogEntry])
def list_profiles() -> list[ProfileCatalogEntry]:
    return auto_calibration_service.list_profiles()


@router.post("/propose", response_model=AutoCalibrationProposalResponse)
def propose(request: AutoCalibrationRequest) -> AutoCalibrationProposalResponse:
    try:
        return auto_calibration_service.propose(request)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/validate", response_model=AutoCalibrationValidationResponse)
def validate(request: AutoCalibrationValidationRequest) -> AutoCalibrationValidationResponse:
    try:
        return auto_calibration_service.validate(request)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/adopt", response_model=AutoCalibrationAdoptResponse)
def adopt(request: AutoCalibrationAdoptRequest) -> AutoCalibrationAdoptResponse:
    try:
        return auto_calibration_service.adopt(request)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/history", response_model=list[AutoCalibrationAuditRecord])
def history() -> list[AutoCalibrationAuditRecord]:
    return auto_calibration_audit_store.list_records()
