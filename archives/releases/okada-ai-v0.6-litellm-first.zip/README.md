# Okada AI Kernel Service (LiteLLM Integration Pack)

This repository is the runtime-integration expansion of the bootstrap implementation for the Okada Governance Kernel.

## What is included
- FastAPI service for `/okada/diagnose`, `/okada/route`, `/okada/intervene`, `/okada/audit`, `/healthz`
- Source-of-truth specs under `specs/okada-ai-spec/`
- Adapter stubs for monitoring / drift / agent / rag / routing
- JSONL-backed audit persistence
- Runtime integration examples for:
  - Dify HTTP Request + Code Node
  - LiteLLM Proxy custom pre/post hooks
  - LangGraph interrupt-based agent governance
  - Open WebUI Pipe / Filter style extensions
- Smoke tests and fixture loading script

## Important limitations
This is still not the final calibrated system.
Thresholds and weights remain placeholders.
The goal of this pack is to provide:
- stable interfaces
- executable kernel service
- concrete runtime integration templates
- code-generation-ready handoff material

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
uvicorn app.main:app --app-dir apps/okada-kernel-service --reload --port 8080
```

## Run tests
```bash
pytest apps/okada-kernel-service/tests -q
```

## Runtime integration quick map
- `examples/dify/`:
  blueprint and payloads for calling the kernel from Dify via HTTP Request node and post-processing via Code node.
- `examples/litellm/`:
  LiteLLM proxy config template, route map, config renderer, preflight checks, and custom callback handler that calls the kernel before/after model execution.
- `examples/langgraph/`:
  interrupt-driven graph example that uses the kernel for continue / replan / handoff / abort decisions.
- `examples/openwebui/`:
  Pipe and Filter examples for routing and audit/governance.

## Repository layout
- `apps/okada-kernel-service/`: service implementation
- `specs/okada-ai-spec/`: source-of-truth specification pack
- `examples/`: runtime integration examples
- `scripts/`: validation and smoke utilities
- `ops/`: deployment and environment examples
