# LiteLLM Integration (v0.6)

This folder contains a more deployment-oriented LiteLLM integration kit.

## Included
- `okada_custom_handler.py`: pre/post hook that calls the Okada Kernel
- `proxy_config.template.yaml`: renderable LiteLLM proxy config template
- `route_map.json`: action-to-model mapping used by the hook
- `request_metadata_mapping.md`: metadata contract from app/request into routing observables

## Minimal path
1. Start the kernel service on `OKADA_BASE_URL`
2. Render `proxy_config.template.yaml` into a concrete `config.yaml`
3. Set `OKADA_ROUTE_MAP_PATH` to `examples/litellm/route_map.json`
4. Start LiteLLM with the rendered config and custom callback enabled

## Required request metadata for best results
- `complexity_proxy`
- `historical_route_success`
- `budget_remaining`
- `latency_load_state`
- `risk_class`
- `question_time_sensitivity`

All metadata keys are optional in the example, but route quality will be weak if they are absent.


## Import path note
Set `PYTHONPATH` so the callback can import `app.*` from `apps/okada-kernel-service`.
