from __future__ import annotations

import os
from typing import Any, Literal

import httpx

try:
    from litellm.integrations.custom_logger import CustomLogger
    from litellm.proxy.proxy_server import DualCache, UserAPIKeyAuth
except Exception:  # pragma: no cover - documentation/runtime fallback only
    class CustomLogger:  # type: ignore[override]
        pass

    class DualCache:  # pragma: no cover
        pass

    class UserAPIKeyAuth:  # pragma: no cover
        pass

from app.integrations.litellm_runtime import (
    apply_routing_decision,
    build_audit_payload,
    build_routing_payload,
    load_route_map,
)


class OkadaLiteLLMHandler(CustomLogger):
    def __init__(self) -> None:
        super().__init__()
        self.okada_base_url = os.getenv("OKADA_BASE_URL", "http://localhost:8080").rstrip("/")
        self.okada_shared_token = os.getenv("OKADA_SHARED_TOKEN")
        self.route_map = load_route_map(os.getenv("OKADA_ROUTE_MAP_PATH"))
        self.policy_profile = {
            "profile_name": os.getenv("OKADA_POLICY_PROFILE", "default"),
            "deterministic_mode": os.getenv("OKADA_DETERMINISTIC_MODE", "true").lower() == "true",
        }

    def _headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.okada_shared_token:
            headers["Authorization"] = f"Bearer {self.okada_shared_token}"
        return headers

    async def async_pre_call_hook(
        self,
        user_api_key_dict: UserAPIKeyAuth,
        cache: DualCache,
        data: dict,
        call_type: Literal[
            "completion",
            "text_completion",
            "embeddings",
            "image_generation",
            "moderation",
            "audio_transcription",
        ],
    ):
        payload = build_routing_payload(data, policy_profile=self.policy_profile)
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(
                f"{self.okada_base_url}/okada/route",
                json=payload,
                headers=self._headers(),
            )
            response.raise_for_status()
            route_decision = response.json()

        return apply_routing_decision(data, route_decision, route_map=self.route_map)

    async def async_post_call_success_hook(
        self,
        data: dict,
        user_api_key_dict: UserAPIKeyAuth,
        response: Any,
    ) -> Any:
        audit_trace_id = data.get("metadata", {}).get("okada_audit_trace_id", "")
        if not audit_trace_id:
            return response

        response_summary = {
            "status": "success",
            "response_type": type(response).__name__,
        }
        audit_payload = build_audit_payload(data, response_summary=response_summary)

        async with httpx.AsyncClient(timeout=10.0) as client:
            try:
                await client.post(
                    f"{self.okada_base_url}/okada/audit",
                    json=audit_payload,
                    headers=self._headers(),
                )
            except Exception:
                pass
        return response
