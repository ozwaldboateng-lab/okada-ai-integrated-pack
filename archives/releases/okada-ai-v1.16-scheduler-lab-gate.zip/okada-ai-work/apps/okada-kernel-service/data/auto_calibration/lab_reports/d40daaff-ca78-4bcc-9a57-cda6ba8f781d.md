# Calibration Lab Report d40daaff-ca78-4bcc-9a57-cda6ba8f781d

- profile_name: routing_default
- spec_id: OKD-AI-005
- adapter_type: routing
- suite_name: routing_replay_smoke
- proposal_source: generated_proposal

## Summary

- current_total_gain_vs_baseline: 1.12
- proposed_total_gain_vs_baseline: 1.12
- proposed_total_gain_vs_current: 0.0
- current_preferred_match_rate: 1.0
- proposed_preferred_match_rate: 1.0

## Policies

### Current Policy
```json
{
  "profile_name": "routing_default",
  "deterministic_mode": true,
  "thresholds": {
    "T_clean": 0.4946,
    "T_contam": 0.8198,
    "high_risk_bonus": 0.15,
    "promotion_threshold": 0.7628
  },
  "weights": {
    "W_dom": 1.5865,
    "W_hist": 0.5,
    "W_comp": 1.0748
  },
  "preferred_actions": {}
}
```

### Proposed Policy
```json
{
  "profile_name": "routing_default",
  "deterministic_mode": true,
  "thresholds": {
    "T_clean": 0.2446,
    "T_contam": 0.5698,
    "high_risk_bonus": 0.15,
    "promotion_threshold": 0.5707
  },
  "weights": {
    "W_dom": 2.0,
    "W_hist": 0.5544,
    "W_comp": 0.5653
  },
  "preferred_actions": {}
}
```

## Case Results

| scenario_id | baseline_action | current_action | proposed_action | current_gain | proposed_gain | proposed_vs_current |
|---|---|---|---|---:|---:|---:|
| routing-hard-high-risk | cheap_route | bounded_hybrid | bounded_hybrid | 0.6500 | 0.6500 | 0.0000 |
| routing-easy-low-risk | promote_strong_model | cheap_route | cheap_route | 0.4700 | 0.4700 | 0.0000 |
